//=============================================================================
//
// "�G001"�GAI�̃x�[�X���� [EnemyAI.cpp] {CEnemyAIBase}
// Author : Yuto Kodama
//
//=============================================================================
#include "EnemyAI.h"
#include "renderer.h"
#include "manager.h"
#include "player.h"
#include "enemy.h"
#include "motion.h"
#include "MapChip.h"

#include <math.h>
//==============================================================
// ����������{CEnemyAIBase}
//==============================================================
void CEnemyAIBase::Init(CEnemy* pThis)
{
	m_pThisEnemy = pThis;

	if (m_pThisEnemy != NULL)
	{
		m_EnemyOrgPos = m_pThisEnemy->Getpos();
	}
}

//==============================================================
// AI��������{CEnemyAIBase}
//==============================================================
CEnemyAIBase* CEnemyAIBase::Create(ENEMY_TYPE Etype, CEnemy* pThis)
{
	CEnemyAIBase* pAIBase = NULL;
	if (pAIBase == NULL)
	{
		switch (Etype)
		{
		case TYPE_NORMAL:
			pAIBase = new CEnemyAI_Normal;
			break;
		case TYPE_SLEEP:
			pAIBase = new CEnemyAI_Sleep;
			break;
		case TYPE_TRAP:
			pAIBase = new CEnemyAI_TrapFlower;
			break;
		case TYPE_SIGNBOARD:
			pAIBase = new CEnemyAI_SignBoard;
			break;
		case TYPE_STAGBEETLE:
			pAIBase = new CEnemyAI_StagBeetle;
			break;
		case TYPE_BOSS:
			pAIBase = new CEnemyAI_BOSS;
			break;
		}
		if (pAIBase != NULL)
		{
			pAIBase->Init(pThis);
		}
	}

	return pAIBase;
}

//==============================================================
// �p�x�v�Z����{CEnemyAIBase}
//==============================================================
float CEnemyAIBase::PlayerHoming(bool bClampFlag)
{
	D3DXVECTOR3 &PlayerPos = CManager::GetPlayer(0)->Getpos();		//�v���C���̍��W
	D3DXVECTOR3 &ThisPos = m_pThisEnemy->Getpos();					//���g�̍��W
																	//�U���p�̌����ݒ�
	float fHomingRot = atan2f(PlayerPos.x - ThisPos.x, PlayerPos.z - ThisPos.z) + D3DX_PI;
	if (fHomingRot > D3DX_PI)
	{
		fHomingRot -= D3DX_PI * 2.0f;
	}
	else if (fHomingRot < -D3DX_PI)
	{
		fHomingRot += D3DX_PI * 2.0f;
	}

	if (bClampFlag == true)
	{
		//�������ɕ␳����
		if ((int)((fHomingRot) / fabs(fHomingRot)) == 1)
		{//������+�����Ȃ�
			fHomingRot = D3DX_PI * 0.5f;
		}
		else
		{//-�����Ȃ�
			fHomingRot = -D3DX_PI * 0.5f;
		}
	}
	return fHomingRot;
}
//==============================================================
// ��_�Ԑ��`��ԏ���{CEnemyAIBase}
//==============================================================
D3DXVECTOR3 CEnemyAIBase::SimpleLeap(D3DXVECTOR3 start, D3DXVECTOR3 goal, float fTime)
{
	D3DXVECTOR3 result;

	D3DXVec3Lerp(&result, &start, &goal, fTime);

	return result;
}

//=============================================================================
//
// "�G001"��{�GAI�̏��� [EnemyAI.cpp] {CEnemyAI_Normal}
// Author : Yuto Kodama
//
//=============================================================================

//*****************************************************************************
// �}�N����`
//*****************************************************************************
#define ATTACK_INTERVAL (30)			//�U���Ԋu
#define ATTACK_LENGTH   (300.0f)		//�U���͈�

//==============================================================
// ����������{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::Init(CEnemy* pThis) {

	CEnemyAIBase::Init(pThis);
	//�����l�ݒ�
	m_vecLeapPos[0] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vecLeapPos[1] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_nNumLeap = 0;
	m_nCntAttackInterval = 0;
	m_AItype = TYPE_NORMAL;
	m_bDamageFlag = true;
}

//==============================================================
// �I������{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_Normal}
//==============================================================
bool CEnemyAI_Normal::AIUpdate(void) {
	if (m_pThisEnemy != NULL)
	{
		bool bMove = true;
		D3DXVECTOR3 &PlayerPos = CManager::GetPlayer(0)->Getpos();		//�v���C���̍��W
		D3DXVECTOR3 &ThisPos = m_pThisEnemy->Getpos();					//���g�̍��W
		float fResult = 0.0f;
		//�ړ��ʂ̔{���ݒ�
		m_pThisEnemy->GetMoveScaling() = 0.25f;

		//�ړ�����
		if (m_nCntAttackInterval == 0)
		{
			if (m_pThisEnemy->GetnNumMotion(1) != 2)
			{
				fResult = CalMoveVector(NULL, ThisPos) + D3DX_PI;
			}
			m_pThisEnemy->SetNextMotion(1);
		}
		else { bMove = false; }

		//�U���p�̌����ݒ�
		float fAttackRot = PlayerHoming(true);

		//�U������
		if (sqrtf((PlayerPos.x - ThisPos.x) * (PlayerPos.x - ThisPos.x) +
			(PlayerPos.y - ThisPos.y) * (PlayerPos.y - ThisPos.y) +
			(PlayerPos.z - ThisPos.z) * (PlayerPos.z - ThisPos.z)) <= ATTACK_LENGTH)
		{
			if (m_pThisEnemy->GetnNumMotion(1) != 2)
			{
				fResult = fAttackRot;
				m_nCntAttackInterval++;
			}
		}
		else
		{
			m_nCntAttackInterval = 0;
		}

		if (m_nCntAttackInterval >= ATTACK_INTERVAL)
		{
			fResult = fAttackRot;
			m_pThisEnemy->SetNextMotion(2);

			m_nCntAttackInterval = 0;
		}

		//�ړ��ƍU���ŎZ�o�������ʂ���
		m_pThisEnemy->GetfRot() = fResult;

		return bMove;
	}

	return false;
}

//==============================================================
// �ړ��p�x�v�Z����{CEnemyAI_Normal}
//==============================================================
float CEnemyAI_Normal::CalMoveVector(float* pOut, D3DXVECTOR3 pos) {
	D3DXVECTOR3 posDest = m_vecLeapPos[m_nNumLeap];	//�ڕW
	float fRot = 0.0f;

	if (sqrtf((posDest.x - pos.x) * (posDest.x - pos.x) +
		(posDest.y - pos.y) * (posDest.y - pos.y) +
		(posDest.z - pos.z) * (posDest.z - pos.z)) >= 5.0f)
	{//�ڕW�Ƃ̋��������ȉ��Ȃ�
		fRot = atan2f(posDest.x - pos.x, posDest.z - pos.z);
	}
	else
	{
		m_nNumLeap = (m_nNumLeap + 1) % 2;
	}

	if (pOut != NULL) { *pOut = fRot; }//���ʂ��i�[

	return fRot;
}

//==============================================================
// �ڕW�n�_�ݒ菈��{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::SetVecLeapPos(D3DXVECTOR3 start, D3DXVECTOR3 goal) {
	m_vecLeapPos[0] = start;
	m_vecLeapPos[1] = goal;
}
//==============================================================
// ��������{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::DamageReaction(float& fValue)
{
	m_pThisEnemy->SetCancelMotion(CMotion::CHIKKUN_DEAD);

	//�����Ă�����Ƌt�ɐ�����΂�
	//float fRot = m_pThisEnemy->GetfRot();
	//m_pThisEnemy->Getmove() += D3DXVECTOR3(sinf(fRot) * 13.0f, 11.0f, cosf(fRot) * 13.0f);
}

//=============================================================================
//
// "�G002"�����GAI�̏��� [EnemyAI.cpp] {CEnemyAI_Sleep}
// Author : Yuto Kodama
//
//=============================================================================

//==============================================================
// ����������{CEnemyAI_Sleep}
//==============================================================
void CEnemyAI_Sleep::Init(CEnemy* pThis) {
	CEnemyAIBase::Init(pThis);
	m_nCntSleepInterval = 0;
	m_AItype = TYPE_SLEEP;
	m_bDamageFlag = true;
	pThis->SetCancelMotion(CMotion::CHIKKUN_SLEEP);
	pThis->GetpParts()[0]->Set(6, &pThis->GetpParts()[0]->GetBone()[6].GetMtx(), CCharParts::PARTS_MAX);
	pThis->SettingMotion();
}

//==============================================================
// �I������{CEnemyAI_Sleep}
//==============================================================
void CEnemyAI_Sleep::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_Sleep}
//==============================================================
bool CEnemyAI_Sleep::AIUpdate(void) {

	if (m_pThisEnemy != NULL)
	{
		m_pThisEnemy->GetMoveScaling() = 0.0f;	//�ړ������Ȃ�����
		m_pThisEnemy->SetNextMotion(0);			//�������[�V�����ɂ���
	}

	return false;
}

//=============================================================================
//
// "�G003"�g���b�v�t�����[AI�̏��� [EnemyAI.cpp] {CEnemyAI_TrapFlower}
// Author : Yuto Kodama
//
//=============================================================================
#define JUMP_HEIGHT     (6.5f)		//�W�����v���̈ړ���
#define HIGHJUMP_HEIGHT (11.5f)		//��W�����v���̈ړ���

//==============================================================
// ����������{CEnemyAI_TrapFlower}
//==============================================================
void CEnemyAI_TrapFlower::Init(CEnemy* pThis) {
	CEnemyAIBase::Init(pThis);
	m_AItype = TYPE_TRAP;
	m_nCntHighJump = 0;
	m_pThisEnemy->GetnNumMotion(0) = 0;
	m_FlowerState = CMotion::FLOWER_Breathing;
	m_ItemState = NO_ITEM;
	m_fFloorHeight = pThis->Getpos().y;
	m_bDamageFlag = false;
	m_bTrapSpawn = false;
	if (m_pThisEnemy != NULL)
	{
		m_pThisEnemy->GetbJump() = true;
	}
}

//==============================================================
// �I������{CEnemyAI_TrapFlower}
//==============================================================
void CEnemyAI_TrapFlower::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_TrapFlower}
//==============================================================
bool CEnemyAI_TrapFlower::AIUpdate(void) {
	if (m_pThisEnemy != NULL)
	{
		switch (m_FlowerState)
		{
		case CMotion::FLOWER_Breathing:
			if (m_bTrapFlag) { m_pThisEnemy->SetCancelMotion(CMotion::FLOWER_NoBreathing); }
			break;
		case CMotion::FLOWER_Trap:
			Move();					//���ňړ�
			break;
		}
	}
	return true;
}

//==============================================================
// ��������{CEnemyAI_TrapFlower}
//==============================================================
void CEnemyAI_TrapFlower::DamageReaction(float& fValue)
{
	//CPlayer* pPlayer = CManager::GetPlayer(0);
	if (m_bTrapFlag == true)
	{
		if (m_FlowerState != CMotion::FLOWER_Trap)
		{
			m_FlowerState = CMotion::FLOWER_Trap;
			m_pThisEnemy->SetCancelMotion(5);
			fValue = 0.0f;
			m_bDamageFlag = true;
		}
		else
		{

		}

		//�����Ă�����Ƌt�ɐ�����΂�
		float fRot = PlayerHoming(true);
		m_pThisEnemy->Getmove() = D3DXVECTOR3(sinf(fRot) * 13.0f, 11.0f, cosf(fRot) * 13.0f);
	}
	else
	{
		m_pThisEnemy->SetCancelMotion(3);
		if (m_ItemState == NO_ITEM)
		{
			//�����Ă�����Ƌt�ɐ�����΂�
			float fRot = PlayerHoming(true);
			fValue = 0.0f;
			m_pThisEnemy->Getmove() = D3DXVECTOR3(sinf(fRot) * 12.0f, 0.0f, cosf(fRot) * 12.0f);
		}
		else
		{

		}
	}

}

//==============================================================
// ��яオ�鏈��
//==============================================================
void CEnemyAI_TrapFlower::StampReaction(CPlayer* pPlayer)
{
	if (m_pThisEnemy->Getrot().x == 0.0f)
	{//�ʏ�o�i�o�i
		CCharacter *pChar = pPlayer;
		pPlayer->SetCancelMotion(CPlayer::MOTION_JUMP);
		pPlayer->Getmove().y = 0.0f;
		if (m_pThisEnemy->GetpParts()[0]->GetType() == CCharParts::TYPE_FIRST)
		{
			CManager::GetSound()->Play(CSound::LABEL_SPRING);
			pPlayer->Getpos().y = m_pThisEnemy->Getpos().y + pPlayer->Getlength().y;
			pPlayer->Getmove().y = 5.0f;
		}
		else { m_pThisEnemy->Damage(1.0f, pChar); }
		m_pThisEnemy->SetCancelMotion(4);
	}
	else
	{//�΂߃o�i�t�b�V��
		CManager::GetSound()->Play(CSound::LABEL_SPRING);
		CMapChip::MAP &Map = CManager::GetpMapChip()->GetMap();
		float fRot = m_pThisEnemy->Getrot().y + D3DX_PI;
		if (pPlayer->GetnID() == 0 && Map == CMapChip::MAP_BOSS)
		{//1P�Ȃ�J������]
			CPlayer::GetfCameraAngle() = m_pThisEnemy->Getrot().y;
			CPlayer::GetfOperationWait() = 60.0f;
		}

		if (fRot > D3DX_PI) { fRot -= D3DX_PI * 2.0f; }
		pPlayer->Getrot().y = fRot;
		pPlayer->GetfRot() = fRot;
		pPlayer->GetfARot() = fRot;
		pPlayer->SetCancelMotion(CPlayer::MOTION_BANE_JUMP);
		pPlayer->Getmove() *= 0.0f;
		pPlayer->Getpos() = m_pThisEnemy->Getpos() + D3DXVECTOR3(sinf(fRot) * -40.0f, 80.0f, cosf(fRot) * -40.0f);
		pPlayer->Getmove() = D3DXVECTOR3(sinf(fRot), 00.0f, cosf(fRot)) * -1.0f;

		if (Map != CMapChip::MAP_BOSS)
		{
			pPlayer->Getmove() = D3DXVECTOR3(sinf(fRot), 00.0f, cosf(fRot)) * 2.0f;
		}

		m_pThisEnemy->GetfARot() = m_pThisEnemy->Getrot().y;
		m_pThisEnemy->SetCancelMotion(4);
	}
}

//==============================================================
// �ړ�����{CEnemyAI_TrapFlower}
//==============================================================
void CEnemyAI_TrapFlower::Move(void)
{
	D3DXVECTOR3 move = m_pThisEnemy->Getmove();
	m_pThisEnemy->SetNextMotion(5);
	m_pThisEnemy->GetMoveScaling() = 1.0f;	//�ړ��𐧌�����(�e�X�g�p)

											//�ړ��p�̌����ݒ�
	float fMoveRot = PlayerHoming(true);
	if (fMoveRot > 0.0f) { move.x -= 2.5f; }
	else { move.x += 2.5f; }

	if (m_pThisEnemy->Getpos().y <= m_fFloorHeight)
	{//���n���Ă�����
		m_pThisEnemy->GetbJump() = true;
	}

	if (m_pThisEnemy->GetbJump() == true)
	{

		if (m_nCntHighJump != 0)
		{
			move = D3DXVECTOR3(move.x, JUMP_HEIGHT, move.z);
		}
		else
		{
			move = D3DXVECTOR3(move.x, HIGHJUMP_HEIGHT, move.z);
		}
		m_pThisEnemy->Getmove() = move;
		m_pThisEnemy->GetbJump() = false;
		m_nCntHighJump = (m_nCntHighJump + 1) % (m_nHighJumpInterval);
	}

	//��W�����v���ɉ���ʂ蔲���₷���悤�ɏd�͂𒲐�����
	int nSign = (int)((move.y) / fabs(move.y)) * -1;	//�d�͒����p�̕����ݒ�
	m_pThisEnemy->Getmove().y += (0.11f * nSign);

}
void CEnemyAI_TrapFlower::SetTrapSpawnFlag(bool bTrapSpawn)
{
	m_bTrapSpawn = bTrapSpawn;
	bTrapSpawn == true ? m_FlowerState = CMotion::FLOWER_Trap : m_FlowerState = CMotion::FLOWER_Breathing;
	m_pThisEnemy->GetnNumMotion(0) = (int)m_FlowerState;
	m_bDamageFlag = bTrapSpawn;
};

//=============================================================================
//
// "�G004"�J���o�������GAI�̏��� [EnemyAI.cpp] {CEnemyAI_SignBoard}
// Author : Yuto Kodama
//
//=============================================================================

//==============================================================
// ����������{CEnemyAI_SignBoard}
//==============================================================
void CEnemyAI_SignBoard::Init(CEnemy* pThis) {
	CEnemyAIBase::Init(pThis);
	m_AItype = TYPE_SIGNBOARD;
	m_bDamageFlag = true;
}

//==============================================================
// �I������{CEnemyAI_SignBoard}
//==============================================================
void CEnemyAI_SignBoard::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_SignBoard}
//==============================================================
bool CEnemyAI_SignBoard::AIUpdate(void) {
	return false;
}

//==============================================================
// ��������{CEnemyAI_SignBoard}
//==============================================================
void CEnemyAI_SignBoard::DamageReaction(float& fValue)
{
	float fRot = 0.0f;
	switch (CManager::GetMode())
	{
	case CManager::MODE_SELECT:
		fRot = D3DX_PI * 0.65f;
		break;
	default:
		fRot = m_pThisEnemy->GetfRot();
		break;
	}
	m_pThisEnemy->Getmove() += D3DXVECTOR3(sinf(fRot) * 30.0f, 15.0f, cosf(fRot) * 30.0f);
}
//=============================================================================
//
// "�G005"�N���K�^�GAI�̏��� [EnemyAI.cpp] {CEnemyAI_StagBeetle}
// Author : Yuto Kodama
//
//=============================================================================

//==============================================================
// ����������{CEnemyAI_StagBeetle}
//==============================================================
void CEnemyAI_StagBeetle::Init(CEnemy* pThis)
{
	CEnemyAIBase::Init(pThis);
}

//==============================================================
// �I������{CEnemyAI_StagBeetle}
//==============================================================
void CEnemyAI_StagBeetle::Uninit(void)
{

}

//==============================================================
// �X�V����{CEnemyAI_StagBeetle}
//==============================================================
bool CEnemyAI_StagBeetle::AIUpdate(void)
{
	return true;
}

//=============================================================================
//
// "�G006"�{�XAI�̏��� [EnemyAI.cpp] {CEnemyAI_BOSS}
// Author : Yuto Kodama
//
//=============================================================================
//==============================================================
// ����������{CEnemyAI_BOSS}
//==============================================================
void CEnemyAI_BOSS::Init(CEnemy* pThis)
{
	CPlayer* pPlayer = CManager::GetPlayer(0);

	CEnemyAIBase::Init(pThis);
	m_AItype = TYPE_BOSS;
	m_CullentPattern = BOSS_CONVERSE;
	m_nActionTime = 300;
	m_nCount = 0;
	m_nNumLeap = 0;
	m_nLeapTime = 0;


	if (m_pThisEnemy != NULL)
	{
		//�v���C���[�̌��݈ʒu�ɉ�����Z�̈ʒu�����߂�
		float fMoveLineZ = 0.0f;
		fabsf(935.0f - pPlayer->Getpos().z) < 5.0f ? fMoveLineZ = 935.0f : fMoveLineZ = 170.0f;

		m_pThisEnemy->GetColSize() = 60.0f;
		m_pThisEnemy->GetfLife() = 30.0f;
		m_vecLeapPos[0] = m_pThisEnemy->Getpos();
		m_vecLeapPos[1] = m_EnemyOrgPos;

		m_BossDefaultPos = m_pThisEnemy->Getpos();

		m_pThisEnemy->Getlength() = D3DXVECTOR3(125.0f, 400.0f, 125.0f);
	}
}

//==============================================================
// �I������{CEnemyAI_BOSS}
//==============================================================
void CEnemyAI_BOSS::Uninit(void)
{
}

//==============================================================
// �X�V����{CEnemyAI_BOSS}
//==============================================================
bool CEnemyAI_BOSS::AIUpdate(void)
{
	//�f�o�b�N
	CDebugLog* pLog = CManager::GetDLog();
	D3DXVECTOR3 pos = m_pThisEnemy->Getpos();
	D3DXVECTOR3 rot = m_pThisEnemy->Getrot();
	pLog->Printf(CDebugLog::MODE_INFO, "\n BOSS_POSITION = %.1f,%.1f,%.1f ", pos.x, pos.y, pos.z);
	pLog->Printf(CDebugLog::MODE_INFO, "\n BOSS_ROTATION = %.1f,%.1f,%.1f ", rot.x, rot.y, rot.z);
	pLog->Printf(CDebugLog::MODE_INFO, "\n BOSS_NUM_LEAP = %d", m_nNumLeap);

	switch (m_CullentPattern)
	{
	case BOSS_NEUTRAL:
		Action_Neutral();
		break;
	case BOSS_BATTLE_START:
		break;
	case BOSS_SIMPLE_MOVE:
		Action_SimpleMove();
		break;
	case BOSS_METEOR_FALL:
		Action_MeteorFall();
		break;
	case BOSS_SHOT_MISSILE:
		Action_ShotMissile();
		break;
	case BOSS_KAMIKAZE_ATTACK:
		break;
	case BOSS_PREPARE_MOVE:
		Action_PrepareMove();
		break;
	case BOSS_CONVERSE:
		Action_Converse();
		break;
	}

	//�J�E���^���Z
	m_nCount++;

	//���̍s�������肷��
	if (m_nCount % m_nActionTime == 0)
	{
		int nTime = 0;
		BOSS_ATTACKPATTERN pattern = ThinkNextAction(nTime);
		if (m_CullentPattern != pattern)
		{
			m_CullentPattern = pattern;
			m_nActionTime = nTime;
		}
		m_nCount = 1;
	}

	return false;
}

//==============================================================
// ��������{CEnemyAI_BOSS}
//==============================================================
void CEnemyAI_BOSS::DamageReaction(float& fValue)
{
	m_pThisEnemy->GetnInvincible() = 30;
}

//==============================================================
// ���̍s�����l���鏈��{CEnemyAI_BOSS}
//==============================================================
CEnemyAI_BOSS::BOSS_ATTACKPATTERN CEnemyAI_BOSS::ThinkNextAction(int &pActionTime)
{//�e�X�g
 //������
	BOSS_ATTACKPATTERN pattern = BOSS_NEUTRAL;
	m_nLeapTime = 0;
	BOSS_ATTACKPATTERN OrgPattern = m_CullentPattern;
	int nRandAction = rand() % 3;
	//int nRandAction = 2;
	CPlayer* pPlayer = CManager::GetPlayer(0);
	m_pThisEnemy->Getrot().y = CEnemyAIBase::PlayerHoming(false);

	m_fShotMissileRot = 0.0f;
	m_fFallMeteorPosZ = 0.0f;

	//�p�x����(z����)
	if (m_pThisEnemy->Getrot().y <= D3DX_PI * 0.5f && m_pThisEnemy->Getrot().y > D3DX_PI * -0.5f)
	{
		//m_pThisEnemy->Getpos().z = m_EnemyOrgPos.z - 100.0f;
		m_BossDefaultPos.z = m_EnemyOrgPos.z - 100.0f;
		m_pThisEnemy->Getrot().y = 0.0f;
	}
	else
	{
		//m_pThisEnemy->Getpos().z = m_EnemyOrgPos.z + 100.0f;
		m_BossDefaultPos.z = m_EnemyOrgPos.z + 100.0f;
		m_pThisEnemy->Getrot().y = D3DX_PI;
	}


	//�v�l
	float fMoveLineZ = 0.0f;

	//�O��̍s���ɂ���Ď��̍s����ς���
	switch (OrgPattern)
	{
	case BOSS_NEUTRAL:
		switch (nRandAction)
		{
		case 0:
			pattern = BOSS_PREPARE_MOVE;
			pActionTime = 210;
			//�v���C���[�̌��݈ʒu�ɉ�����Z�̈ʒu�����߂�
			fabsf(935.0f - pPlayer->Getpos().z) < 400.0f ? fMoveLineZ = 935.0f : fMoveLineZ = 170.0f;

			m_vecLeapPos[0] = D3DXVECTOR3(m_EnemyOrgPos.x + 400.0f, m_EnemyOrgPos.y, fMoveLineZ);
			m_vecLeapPos[1] = D3DXVECTOR3(m_EnemyOrgPos.x - 400.0f, m_EnemyOrgPos.y, fMoveLineZ);
			break;
		case 1:
			pattern = BOSS_METEOR_FALL;
			pActionTime = 420;
			m_fShotMissileRot = m_pThisEnemy->Getrot().y;
			m_pThisEnemy->SetNextMotion(2);
			m_pThisEnemy->Getrot().y += D3DX_PI * 0.25f;
			break;
		case 2:
			pattern = BOSS_SHOT_MISSILE;
			pActionTime = 420;
			m_fFallMeteorPosZ = pPlayer->Getpos().z;
			break;
		}
		break;
	case BOSS_BATTLE_START:
		break;
	case BOSS_SIMPLE_MOVE:
		pattern = BOSS_NEUTRAL;
		pActionTime = 300;
		m_pThisEnemy->Getpos().y = m_EnemyOrgPos.y;
		m_vecLeapPos[0] = m_pThisEnemy->Getpos();
		m_vecLeapPos[1] = m_BossDefaultPos;

		break;
	case BOSS_METEOR_FALL:
		pattern = BOSS_NEUTRAL;
		pActionTime = 300;
		m_pThisEnemy->Getpos().y = m_EnemyOrgPos.y;
		m_vecLeapPos[0] = m_pThisEnemy->Getpos();
		m_vecLeapPos[1] = m_BossDefaultPos;

		break;
	case BOSS_SHOT_MISSILE:
		pattern = BOSS_NEUTRAL;
		pActionTime = 300;
		m_pThisEnemy->Getpos().y = m_EnemyOrgPos.y;
		m_vecLeapPos[0] = m_pThisEnemy->Getpos();
		m_vecLeapPos[1] = m_BossDefaultPos;

		break;
	case BOSS_KAMIKAZE_ATTACK:
		break;
	case BOSS_PREPARE_MOVE:
		pattern = BOSS_SIMPLE_MOVE;
		pActionTime = 400;
		m_nNumLeap == 1 ? m_pThisEnemy->Getrot().y = D3DX_PI * -0.5f : m_pThisEnemy->Getrot().y = D3DX_PI * 0.5f;
		break;

	case BOSS_CONVERSE:
		pattern = BOSS_NEUTRAL;
		pActionTime = 300;
		m_pThisEnemy->Getpos().y = m_EnemyOrgPos.y;
		m_vecLeapPos[0] = m_pThisEnemy->Getpos();
		m_vecLeapPos[1] = m_BossDefaultPos;
		break;
	}
	return pattern;
}

//==============================================================
// �U���p�^�[�����Ƃ̏���{CEnemyAI_BOSS}
//==============================================================
void CEnemyAI_BOSS::Action_Neutral(void)//�ҋ@
{
	m_pThisEnemy->Getrot().y = CEnemyAIBase::PlayerHoming(false);
	//�p�x����(z����)
	if (m_pThisEnemy->Getrot().y <= D3DX_PI * 0.5f && m_pThisEnemy->Getrot().y > D3DX_PI * -0.5f)
	{
		//m_pThisEnemy->Getpos().z = m_EnemyOrgPos.z - 100.0f;
		m_pThisEnemy->Getrot().y = 0.0f;
	}
	else
	{
		//m_pThisEnemy->Getpos().z = m_EnemyOrgPos.z + 100.0f;
		m_pThisEnemy->Getrot().y = D3DX_PI;
	}

	m_pThisEnemy->SetNextMotion(0);

	if (m_nLeapTime <= 100)
	{
		D3DXVECTOR3 result = CEnemyAIBase::SimpleLeap(m_vecLeapPos[0], m_vecLeapPos[1], (float)m_nLeapTime / 100.0f);
		m_pThisEnemy->Getpos().x = result.x;
		m_pThisEnemy->Getpos().z = result.z;

	}

	m_nLeapTime++;


	m_pThisEnemy->Getmove() = D3DXVECTOR3(0.0f, cosf(m_nCount / 30.0f), 0.0f);
}

void CEnemyAI_BOSS::Action_SimpleMove(void)//���E�ړ�
{
	m_pThisEnemy->SetNextMotion(1);
	m_pThisEnemy->Getmove() = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_pThisEnemy->Getpos() = CEnemyAIBase::SimpleLeap(m_vecLeapPos[m_nNumLeap], m_vecLeapPos[(m_nNumLeap + 1) % 2], (float)m_nLeapTime / 200.0f);

	if (m_nLeapTime >= 200)
	{
		m_nNumLeap = (m_nNumLeap + 1) % 2;
		m_pThisEnemy->Getrot().y *= -1;
	}

	m_nLeapTime = (m_nLeapTime + 1) % 201;
}

void CEnemyAI_BOSS::Action_ShotMissile(void)//�~�T�C��
{
	D3DXVECTOR3& pos = m_pThisEnemy->Getpos();
	D3DXVECTOR3& rot = m_pThisEnemy->Getrot();
	CProjectile* pMissile = NULL;

	D3DXVECTOR3 PlayerPos = CManager::GetPlayer(0)->Getpos();

	m_pThisEnemy->SetNextMotion(0);

	m_pThisEnemy->Getmove() = D3DXVECTOR3(0.0f, cosf(m_nCount / 30.0f) * 0.1f, 0.0f);

	float fDest = fabsf(pos.z) - fabsf(PlayerPos.z);
	if (fDest >= 90.0f || fDest <= -90.0f)
	{
		rot.y = CEnemyAIBase::PlayerHoming(false);
		//�p�x����(z����)
		if (rot.y <= D3DX_PI * 0.5f && rot.y > D3DX_PI * -0.5f)
		{
			//pos.z = m_EnemyOrgPos.z + 100.0f;
			rot.y = 0.0f;
		}
		else
		{
			//pos.z = m_EnemyOrgPos.z - 100.0f;
			rot.y = D3DX_PI;
		}

		if (m_nCount % 30 == 0)
		{
			D3DXVECTOR3 missileMuzzle = D3DXVECTOR3(pos.x + (cosf(m_nCount / 10.0f) * 500.0f), PlayerPos.y + 50.0f, pos.z);
			if (SceneCreate(pMissile, 3))
			{
				pMissile->Set(CProjectile::P_MODEL_MISSILE, missileMuzzle,D3DXVECTOR3(0.0f, m_fShotMissileRot - D3DX_PI * 0.5f, 0.0f), 3.0f, 480, false);
			}
		}
	}
	else
	{
		if (m_nCount % 120 == 0)
		{
			D3DXVECTOR3 missileMuzzle = D3DXVECTOR3(PlayerPos.x, pos.y, pos.z);
			if (SceneCreate(pMissile, 3))
			{
				pMissile->Set(CProjectile::P_MODEL_MISSILE, missileMuzzle, D3DXVECTOR3(0.0f, m_fShotMissileRot - D3DX_PI * 0.5f, 0.0f), 3.0f, 240, false);
			}
		}
	}
}

void CEnemyAI_BOSS::Action_MeteorFall(void)//覐�
{
	D3DXVECTOR3& pos = m_pThisEnemy->Getpos();
	CProjectile* pMeteor = NULL;
	CPlayer* pPlayer = CManager::GetPlayer(0);
	D3DXVECTOR3 PlayerPos = pPlayer->Getpos();

	m_pThisEnemy->Getmove() = D3DXVECTOR3(0.0f, cosf(m_nCount / 30.0f) * 0.1f, 0.0f);

	D3DXVECTOR3 meteorMuzzle;

	if (m_nCount % 60 == 0)
	{
		meteorMuzzle = D3DXVECTOR3((cosf(m_nCount / 30.0f) * 450.0f) + pos.x, 1000.0f, m_fFallMeteorPosZ);
		if (SceneCreate(pMeteor, 3))
		{
			pMeteor->Set(CProjectile::P_MODEL_METEOR, meteorMuzzle, D3DXVECTOR3(0.0f, 0.0f, D3DX_PI * 0.5f), 2.0f, 480, false);
		}
	}
	if (m_nCount % 150 == 0)
	{
		meteorMuzzle = D3DXVECTOR3(0.0f, 1000.0f, 0.0f);
		if (pPlayer != NULL)
		{
			meteorMuzzle += D3DXVECTOR3(PlayerPos.x, 50.0f, m_fFallMeteorPosZ);
		}

		if (SceneCreate(pMeteor, 3))
		{
			pMeteor->Set(CProjectile::P_MODEL_METEOR, meteorMuzzle, D3DXVECTOR3(0.0f, 0.0f, D3DX_PI * 0.5f), 2.0f, 480, false);
		}
	}
}

void CEnemyAI_BOSS::Action_PrepareMove(void)	//�ړ�����
{
	const int nMoveTime = 90;
	int nCntMove = 0;
	m_pThisEnemy->Getmove() = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	if (m_nLeapTime <= nMoveTime)
	{
		m_pThisEnemy->Getpos() = CEnemyAIBase::SimpleLeap(m_BossDefaultPos, m_BossDefaultPos + D3DXVECTOR3(0.0f, 1200.0f, 0.0f), (float)m_nLeapTime / nMoveTime);
	}
	else if (m_nLeapTime > nMoveTime && m_nLeapTime <= (nMoveTime * 2))
	{
		nCntMove = m_nLeapTime - nMoveTime;
		m_pThisEnemy->Getpos() = CEnemyAIBase::SimpleLeap(m_vecLeapPos[m_nNumLeap] + D3DXVECTOR3(0.0f, 400.0f, 0.0f), m_vecLeapPos[m_nNumLeap], (float)nCntMove / nMoveTime);

	}
	else
	{

	}
	m_pThisEnemy->SetNextMotion(0);
	m_nLeapTime++;

}
void CEnemyAI_BOSS::Action_Converse(void)	//	��b
{
	m_pThisEnemy->Getpos().z = m_EnemyOrgPos.z - 100.0f;

	m_pThisEnemy->Getrot().y = CEnemyAIBase::PlayerHoming(false);
	m_pThisEnemy->Getmove() = D3DXVECTOR3(0.0f, cosf(m_nCount / 30.0f), 0.0f);

}
//==============================================================
// �U���p�^�[���Z�b�g����{CEnemyAI_BOSS}
//==============================================================
void CEnemyAI_BOSS::SetNextAction(BOSS_ATTACKPATTERN pattern, int nActTime)
{
	m_CullentPattern = pattern;
	m_nActionTime = nActTime;
}
//==============================================================
// �U���X�^�[�g����{CEnemyAI_BOSS}
//==============================================================
void CEnemyAI_BOSS::AIStart(void)
{
	CEnemy* pBoss = NULL;
	pBoss = CEnemy::GetBoss();
	if (pBoss != NULL)
	{
		CEnemyAI_BOSS* pAIBoss = (CEnemyAI_BOSS*)pBoss->GetAI();
		pAIBoss->SetNextAction(CEnemyAI_BOSS::BOSS_NEUTRAL, 300);
	}
}