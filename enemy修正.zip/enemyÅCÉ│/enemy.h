//=============================================================================
//
// �G�l�~�[���� [enemy.h]
// Author : Ryo Sugimoto
// Editor : Yuto Kodama
//
//=============================================================================
#ifndef _ENEMY_H_
#define _ENEMY_H_

#include "main.h"
#include "scene.h"
#include "motion.h"
#include "EnemyAI.h"
class CPlayer;
class CEnemyAIBase;

//*****************************************************************************
// �\���̂̒�`
//*****************************************************************************

//*****************************************************************************
// �N���X�̒�`
//*****************************************************************************
class CEnemy : public CCharacter
{
public:

	typedef enum
	{
		TYPE_NONE,
		TYPE_GOBURINN,
		TYPE_TITLE,
		TYPE_VERSUS,
		TYPE_PRACTICE,
		TYPE_MAX
	}TYPE;

	CEnemy(int nPrioryity = CHAR_PRIORITY) : CCharacter::CCharacter(nPrioryity) {};
	~CEnemy() {};

	void	Set(D3DXVECTOR3 pos, D3DXVECTOR3 rot, CMotion::TYPE Mtype, TYPE type,CEnemyAIBase::ENEMY_TYPE Etype);		//�Z�b�g����
	HRESULT Init(void);																				//����������
	void	Update(void);																			//�X�V����
	void	Draw(void);																				//�`�揈��
	void	Dead(void);																				//���S����
	void	Over(void);																				//��������

	CCharacter *&GetpTarget(void)	{ return m_pTarget; }

	//AI�ݒ�(�I�[�o�[���[�h)
	void SetAIState(CEnemyAIBase::ENEMY_TYPE type) {};
	void SetAIState(CEnemyAIBase::ENEMY_TYPE type,D3DXVECTOR3 start,D3DXVECTOR3 goal);	//��_�Ԉړ��G
	void SetAIState(CEnemyAIBase::ENEMY_TYPE type,float fOrgHeight,int nJumpInterval);	//�g���b�v�t�����[

private:
	//�ϐ��錾
	CScene::TEXTURE tex;
	TYPE		m_Type;
	float		m_fMove;
	int			m_nCntFrame;
	int			m_nMaxFrame;
	bool		m_bDraw;
	CCharacter	*m_pTarget;

	//AI
	CEnemyAIBase*	m_pEnemyAI;
};

#endif
