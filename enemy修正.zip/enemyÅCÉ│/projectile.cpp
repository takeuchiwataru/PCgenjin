//=============================================================================
//
// �{�X�̃~�T�C������ [BossMissile.cpp]
// Author : Yuto Kodama
//
//=============================================================================
#include "projectile.h"
#include "manager.h"

//==============================================================
//   �~�T�C���̐ݒ菈��
//==============================================================
void CProjectile::Set(PROJECTILE_MODEL model, D3DXVECTOR3 pos, D3DXVECTOR3 rot, float fMoveSpeed, int nLife, bool bAccel)
{
	CSceneModel::MODEL Model;
	D3DXCOLOR col = D3DXCOLOR(1.0f,1.0f,1.0f,1.0f);
	switch (model)
	{
	case CProjectile::P_MODEL_MISSILE:
		Model = CSceneModel::MODEL_MISSILE;
		break;
	case CProjectile::P_MODEL_METEOR:
		Model = CSceneModel::MODEL_STONE;
		break;
	}
	CSceneModel::Set(pos,rot,col,Model,CScene::DRAW_TYPE_NORMAL,false);
	m_fSpeed = fMoveSpeed;
	if(nLife > 0){ m_nLife = nLife; }
	m_bAccel = bAccel;

	//�Z�b�g�ł��Ȃ����l�̏�����
	m_PosOld = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_Move = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
}

//==============================================================
//   �~�T�C���̏I������
//==============================================================
void CProjectile::Uninit(void)
{
	D3DXVECTOR3 &pos = CSceneModel::GetPosition();

	//�G�t�F�N�g
	CSceneAnim3D	*pAnim;
	if (SceneCreate(pAnim, S3D_PRIORITY))
	{
		pAnim->Set(pos + D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f),
			D3DXVECTOR3(100.0f, 100.0f, 0.0f), CScene::TEX_Over, true, CScene::DRAW_TYPE_ZOVERLAY, 0, 10, 1, 4, CSceneAnim3D::ANIMATION_NORMAL, CScene3D::STATE_NORMAL);
	}
	CScene::Uninit();
}

//==============================================================
//   �~�T�C���̍X�V����
//==============================================================
void CProjectile::Update(void)
{
	D3DXVECTOR3 &pos = CSceneModel::GetPosition();
	D3DXVECTOR3 rot = CSceneModel::GetRotation();
	m_PosOld = pos;

	//�}�g���b�N�X���g�p���Ĉړ��ʂ����߂�
	D3DXVECTOR3 move = D3DXVECTOR3(-m_fSpeed,0.0f,0.0f);

	D3DXMATRIX Mtxmove,Mtxrot,Mtxtrans;
	D3DXMatrixIdentity(&Mtxmove);

	D3DXMatrixTranslation(&Mtxtrans, move.x, move.y, move.z);
	D3DXMatrixMultiply(&Mtxmove, &Mtxmove, &Mtxtrans);
	D3DXMatrixRotationYawPitchRoll(&Mtxrot,rot.y,rot.x,rot.z);
	D3DXMatrixMultiply(&Mtxmove,&Mtxmove,&Mtxrot);

	m_Move = D3DXVECTOR3(Mtxmove._41,Mtxmove._42,Mtxmove._43);	//���W(�ړ���)�����o��

	pos += m_Move;

	if (m_bAccel == true)
	{
		m_fSpeed *= PROJECTILE_ACCELERATE;		//�ړ����x�𑝂₷
	}
	int n = 1;		//�e�X�g

	//�̗͌��炷
	m_nLife--;
	if (m_nLife <= 0)
	{
		m_nLife = 0;
		CProjectile::Uninit();
	}
	else if (n == 0 /*Collision()*/)
	{//�v���C���ɓ������������
		CProjectile::Uninit();
	}
}

//==============================================================
//   �~�T�C���̕`�揈��
//==============================================================
void CProjectile::Draw(void)
{
	SetMtx();
	CSceneModel::Draw();
}
