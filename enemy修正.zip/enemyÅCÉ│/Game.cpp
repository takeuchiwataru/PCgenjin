//=============================================================================
//
// �Q�[������ [Game.cpp]
// Author : Ryo Sugimoto
//
//=============================================================================
#include"Scene.h"
#include"Scene2D.h"
#include "manager.h"
#include "RenderDraw.h"
#include "scene.h"
#include "Effect.h"
#include "player.h"
#include "SceneModel.h"
#include "mesh.h"
#include "dungeon.h"
#include "Font.h"
#include "MapChip.h"

#include "Game.h"
#include "CharSelect.h"
#include "camera.h"
#include "light.h"
#include "wind.h"
#include "sound.h"
//*****************************************************************************
// �ÓI�����o�ϐ�
//*****************************************************************************
bool	CGame::m_bDuo = false;	//2�l�v���C���ǂ���

//=============================================================================
// �Q�[���̏���������
//=============================================================================
HRESULT CGame::Init(void)
{
	m_state = STATE_NONE;
	m_fCntState = 0.0f;
	m_pTime = NULL;

	CMotion::Load();
	CCharacter::Load();

	CLight *pLight;			Create(pLight);		//���C�g�̐���
	CWind_Manager *pWind;	Create(pWind);		//���̐���
	CCamera_Play	*pCamera;

	CPlayer *pPlayer;
	CEnemy *pEnemy;
	//CSceneAnim2D *p2D;
	//CScene3DView	*p3DView;

	//if (SceneCreate(p2D, CHAR_PRIORITY))
	//{//���w�i
	//	p2D->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, 0.0f), SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, D3DX_PI, 0, 2, 10, 2, 0.0f,
	//		CScene2D::STATE_ZCLEAR, CSceneAnim3D::ANIMATION_LOOP, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene::TEX_G_EXPLOSION);
	//}

	//CCharSelect::Load(pChar[0], pChar[1]);
	pCamera = CCamera_Manager::Create_Play(0);
	pCamera->GetChar()->SetViewport(0, 0, 1280, 720);
	pCamera->GetObj()->SetViewport(0, 0, 1280, 720);
	pCamera->GetObj()->GetposV() = D3DXVECTOR3(1130.0f, 100.0f, 20.0f);
	pCamera->GetObj()->GetposR() = D3DXVECTOR3(1130.0f, 0.0f, 19.0f);

	//if (SceneCreate(p3DView, S3D_PRIORITY))
	//{//�L�����쐬
	//	p3DView->Set(D3DXVECTOR3(0.0f, 100.0f, 0.0f), D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3(300.0f, 300.0f, 0.0f), CScene::DRAW_TYPE_NORMAL);
	//}

	if (SceneCreate(pPlayer, CHAR_PRIORITY))
	{//�L�����쐬
		pPlayer->Set(D3DXVECTOR3(MAP_CHIP_SIZE * 1.0f, 0.0f, MAP_CHIP_SIZE * 1.0f), D3DXVECTOR3(0.0f, 0.0f, 0.0f), CMotion::TYPE_PLAYER);
	}
	if (SceneCreate(pEnemy, CHAR_PRIORITY))
	{//�L�����쐬
		pEnemy->Set(D3DXVECTOR3(MAP_CHIP_SIZE * 7.0f, 0.0f, MAP_CHIP_SIZE * 1.0f), D3DXVECTOR3(0.0f, D3DX_PI * 0.5f , 0.0f), CMotion::TYPE_ENEMY_0, CEnemy::TYPE_NONE, 1);
		pEnemy->SetAIState(TYPE_NORMAL, D3DXVECTOR3(MAP_CHIP_SIZE * 5.0f, 0.0f, MAP_CHIP_SIZE * 1.0f), D3DXVECTOR3(MAP_CHIP_SIZE * 8.0f, 0.0f, MAP_CHIP_SIZE * 1.0f));
	}
	if (SceneCreate(pEnemy, CHAR_PRIORITY))
	{//�L�����쐬
		pEnemy->Set(D3DXVECTOR3(MAP_CHIP_SIZE * 22.0f, 0.0f, MAP_CHIP_SIZE * 7.0f), D3DXVECTOR3(0.0f, D3DX_PI * 0.5f, 0.0f), CMotion::TYPE_ENEMY_0, CEnemy::TYPE_NONE, 1);
		pEnemy->SetAIState(TYPE_NORMAL, D3DXVECTOR3(MAP_CHIP_SIZE * 21.0f, 0.0f, MAP_CHIP_SIZE * 7.0f), D3DXVECTOR3(MAP_CHIP_SIZE * 23.0f, 0.0f, MAP_CHIP_SIZE * 7.0f));

	}

	if (SceneCreate(m_pTime, PAUSE_PRIORITY - 1))
	{//�^�C�}�[�̃Z�b�g
		m_pTime->Set(1800);
	}

	for (int nCount = 0; nCount < MAX_OPTION_SELECT; nCount++)
	{//Font�̏�����
		m_pFont[nCount] = NULL;
	}
	//CManager::GetCamera()->SetScene(CCamera_Manager::SCENE_TYPE_LABYRINTH);

	CMapChip *pMap;
	if (SceneCreate(pMap, MAP_PRIORYITY))
	{
		pMap->SampleMap();
		pMap->Load("data/TEXT/EDIT/Editor.txt");
	}
	//CDungeon::SetDungeon_Boss(0);
	return S_OK;
}
//=============================================================================
// �Q�[���̍X�V����
//=============================================================================
void CGame::Update(void)
{
	CInputKeyboard *pInputKey = CManager::GetInputKey();	//�L�[�{�[�h���l��
	CSceneAnim2D *pSceneAnim2D;

	if (pInputKey->GetTrigger(DIK_TAB))
	{
		CRenderDraw::SetFade(CManager::MODE_GAME, CRenderDraw::FADE_NORMAL, CRenderDraw::STATE_FADE_IN);
	}
	switch (m_state)
	{
	case STATE_NONE:
		Pause();	//�|�[�Y�̍X�V
		break;
	case STATE_CLEAR:
		m_fCntState += 1.0f;
		switch ((int)m_fCntState)
		{
		case 60:
			if (SceneCreate(pSceneAnim2D, S2D_PRIORITY))
			{//CLEAR�\�L
				pSceneAnim2D->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, 0.0f), SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2,
					D3DX_PI, 0, 1, 10, 3, 0.0f, CScene2D::STATE_NORMAL, CSceneAnim3D::ANIMATION_LOOP, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene::TEX_CLEAR);
				pSceneAnim2D->BindDrawType(CScene::DRAW_TYPE_MULTIPLY);
			}
			CManager::GetSound()->StopBGM();
			CManager::GetSound()->Play(CSound::LABEL_CLEAR000);
			break;
		case 600: CRenderDraw::SetFade(CManager::MODE_TITLE, CRenderDraw::FADE_NORMAL, CRenderDraw::STATE_FADE_IN); break;
		}
		if (m_fCntState > 180 && (
			CManager::GetInputJoyPad(0)->GetTrigger(INPUT_START) || CManager::GetInputJoyPad(0)->GetTrigger(INPUT_A) || CManager::GetInputJoyPad(0)->GetTrigger(INPUT_B) ||
			CManager::GetInputJoyPad(1)->GetTrigger(INPUT_START) || CManager::GetInputJoyPad(1)->GetTrigger(INPUT_A) || CManager::GetInputJoyPad(1)->GetTrigger(INPUT_B) ||
			CManager::GetInputKey()->GetTrigger(DIK_RETURN)))
		{
			CRenderDraw::SetFade(CManager::MODE_TITLE, CRenderDraw::FADE_NORMAL, CRenderDraw::STATE_FADE_IN);
		}
		break;

	case STATE_OVER:
		m_fCntState += 1.0f;
		switch ((int)m_fCntState)
		{
		case 2:
			break;
		case 60:
			CManager::GetSound()->Play(CSound::LABEL_OVER000);
			break;
		case 1800:
			CRenderDraw::SetFade(CManager::MODE_TITLE, CRenderDraw::FADE_NORMAL, CRenderDraw::STATE_FADE_IN);
			break;
		}
		if (m_fCntState > 90 && (
			CManager::GetInputJoyPad(0)->GetTrigger(INPUT_START) || CManager::GetInputJoyPad(1)->GetTrigger(INPUT_START) ||
			CManager::GetInputJoyPad(0)->GetTrigger(INPUT_A) || CManager::GetInputJoyPad(1)->GetTrigger(INPUT_A) ||
			CManager::GetInputJoyPad(0)->GetTrigger(INPUT_B) || CManager::GetInputJoyPad(1)->GetTrigger(INPUT_B) ||
			CManager::GetInputKey()->GetTrigger(DIK_RETURN)))
		{
			CRenderDraw::SetFade(CManager::MODE_TITLE, CRenderDraw::FADE_NORMAL, CRenderDraw::STATE_FADE_IN);
		}
		break;
	}

}
//=============================================================================
// �Q�[���̏I������
//=============================================================================
void	CGame::Uninit(void)
{
	//BGM�̃X�g�b�v
	CSound *pSound = CManager::GetSound();
	pSound->StopBGM();

	for (int nCount = 0; nCount < MAX_GAME_PAUSE; nCount++)
	{//�S�|�[�Y�̔j��
		if (m_pScene2D[nCount] != NULL)
		{//��������Ă���΍폜
			m_pScene2D[nCount]->Uninit();
			m_pScene2D[nCount] = NULL;
		}
	}
	m_pTime->Uninit(); m_pTime = NULL;
	CManager::GetCamera()->Uninit();
	CManager::GetLight()->Uninit();
}
//=============================================================================
// �Q�[���̏�ԕύX����
//=============================================================================
void	CGame::SetState(STATE state)
{
	CScene2D *pScene2D;

	if (m_state != state)
	{//�ʏ��ԂȂ�
		m_state = state;
		switch (m_state)
		{
		case STATE_CLEAR:
			m_pTime->GetpNumber()->GetState() = CNumber::STATE_SCORE;
			m_fCntState = 0.0f;
			if (SceneCreate(pScene2D, S2D_PRIORITY))
			{//��ʂ��Â�����
				pScene2D->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, 0.0f), SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2,
					D3DX_PI, 0, 1, 1, 0.03f, CScene2D::STATE_FADEIN5, D3DXCOLOR(0.0f, 0.0f, 0.0f, 0.0f), CScene2D::TEX_MAX);
			}
			break;
		case STATE_OVER:
			m_pTime->GetpNumber()->GetState() = CNumber::STATE_SCORE;
			m_fCntState = 0.0f;
			if (SceneCreate(pScene2D, S2D_PRIORITY))
			{//��ʂ��Â�����
				pScene2D->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, 0.0f), SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2,
					D3DX_PI, 0, 1, 1, 0.03f, CScene2D::STATE_FADEIN5, D3DXCOLOR(0.0f, 0.0f, 0.0f, 0.0f), CScene2D::TEX_MAX);
			}
			break;
		case STATE_TIMEUP:
			CManager::GetSound()->StopBGM();
			CCharacter::GetbWait() = true;
			m_fCntState = 0.0f;
			if (SceneCreate(pScene2D, S2D_PRIORITY))
			{//��ʂ��Â�����
				pScene2D->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, 0.0f), SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2,
					D3DX_PI, 0, 1, 1, 0.03f, CScene2D::STATE_FADEIN5, D3DXCOLOR(0.0f, 0.0f, 0.0f, 0.0f), CScene2D::TEX_MAX);
			}
			if (SceneCreate(pScene2D, S2D_PRIORITY))
			{//��ʂ��Â�����
				pScene2D->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, 0.0f), SCREEN_WIDTH / 6, SCREEN_HEIGHT / 6,
					D3DX_PI, 2, 1, 3, 0.0f, CScene2D::STATE_NORMAL, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene2D::TEX_ResultLogo);
			}
			m_state = STATE_OVER;
			break;
		}
	}
}
//=============================================================================
// �T�o�C�o���̃|�[�Y����
//=============================================================================
void	CGame::Pause(void)
{
	if (CManager::GetRenderer()->GetReDraw()->GetState() == CRenderDraw::STATE_NONE)
	{
		CSound *pSound = CManager::GetSound();					//�T�E���h�̃|�C���^���擾
		CInputKeyboard *pInputKey = CManager::GetInputKey();	//�L�[�{�[�h���l��
		CInputJoyPad	*pInputPad0 = CManager::GetInputJoyPad(0);	//�W���C�p�b�h���l��
		CInputJoyPad	*pInputPad1 = CManager::GetInputJoyPad(1);	//�W���C�p�b�h���l��
		bool bSelect = false;
		bool bPause = true;
		int	 nPlus = 0;
		char aStr[64];

		if (!CScene::GetbPause())
		{//�|�[�Y�łȂ�
			if (pInputKey->GetTrigger(DIK_P) || pInputPad0->GetTrigger(INPUT_START) || pInputPad1->GetTrigger(INPUT_START))
			{//�|�[�Y�N��
				CManager::GetSound()->Play(CSound::LABEL_LOCKON);
				CScene::GetbPause() = true;
				bSelect = true;
				m_bOption = false;
				m_nSelect = 1;
				if (pInputPad0->GetTrigger(INPUT_START)) { m_nNumber = 0; }
				else if (pInputPad1->GetTrigger(INPUT_START)) { m_nNumber = 1; }
				else { m_nNumber = 0; }

				if (SceneCreate(m_pScene2D[0], PAUSE_PRIORITY))
				{//��ʈÂ�����
					m_pScene2D[0]->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, 0.0f), SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2,
						D3DX_PI, 0, 1, 1, 0.0f, CScene2D::STATE_NORMAL, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene::TEX_Pause_BG);
				}
				if (SceneCreate(m_pScene2D[1], PAUSE_PRIORITY))
				{//��Z���N�g�@�R���e�j���[
					m_pScene2D[1]->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - GAME_PAUSE_LOGOY - GAME_PAUSE_INTERVAL * 2.0f, 0.0f), GAME_PAUSE_LOGOX, GAME_PAUSE_LOGOY,
						D3DX_PI, 0, 1, 4, 100.0f, CScene2D::STATE_SMALL, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene::TEX_Pause_Logo);
				}
				if (SceneCreate(m_pScene2D[2], PAUSE_PRIORITY))
				{//���Z���N�g�@���g���C
					m_pScene2D[2]->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - GAME_PAUSE_INTERVAL, 0.0f), GAME_PAUSE_LOGOX, GAME_PAUSE_LOGOY,
						D3DX_PI, 1, 1, 4, 100.0f, CScene2D::STATE_SMALL, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene::TEX_Pause_Logo);
				}
				if (SceneCreate(m_pScene2D[3], PAUSE_PRIORITY))
				{//���Z���N�g�@���^�C�A
					m_pScene2D[3]->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 + GAME_PAUSE_INTERVAL, 0.0f), GAME_PAUSE_LOGOX, GAME_PAUSE_LOGOY,
						D3DX_PI, 2, 1, 4, 100.0f, CScene2D::STATE_SMALL, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene::TEX_Pause_Logo);
				}
				if (SceneCreate(m_pScene2D[4], PAUSE_PRIORITY))
				{//���Z���N�g�@�I�v�V����
					m_pScene2D[4]->Set(D3DXVECTOR3(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 + GAME_PAUSE_LOGOY + GAME_PAUSE_INTERVAL * 2.0f, 0.0f), GAME_PAUSE_LOGOX, GAME_PAUSE_LOGOY,
						D3DX_PI, 3, 1, 4, 100.0f, CScene2D::STATE_SMALL, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene::TEX_Pause_Logo);
				}
				if (SceneCreate(m_pScene2D[5], PAUSE_PRIORITY))
				{//�}�[�J�[
					(m_pScene2D[5]->Set(D3DXVECTOR3(SCREEN_WIDTH / 2 - GAME_PAUSE_LOGOX, SCREEN_HEIGHT / 2 + GAME_PAUSE_INTERVAL, 0.0f), 75.0f, 50.0f, D3DX_PI, m_nNumber, 3, 1, 100.0f, CScene2D::STATE_FLASH2, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene::TEX_PIcon));
				}
			}
		}
		else if ((pInputKey->GetTrigger(DIK_P) || pInputPad0->GetTrigger(INPUT_START) || pInputPad1->GetTrigger(INPUT_START)
			|| pInputPad0->GetTrigger(INPUT_B) || pInputPad1->GetTrigger(INPUT_B)) && !m_bOption)
		{//�|�[�Y�~��
			bPause = false;
			CManager::GetSound()->Play(CSound::LABEL_LOCKCANSEL);
		}

		if (CScene::GetbPause())
		{//�|�[�Y��
			pInputPad0 = CManager::GetInputJoyPad(m_nNumber);

			if (pInputKey->GetTPress(DIK_UP) ||
				pInputPad0->GetTPress(INPUT_UP) || pInputPad0->GetTPress(INPUT_LS_U))
			{
				m_nSelect = (m_nSelect - 1 + 3) % 4 + 1; bSelect = true;
			}

			if (pInputKey->GetTPress(DIK_DOWN) ||
				pInputPad0->GetTPress(INPUT_DOWN) || pInputPad0->GetTPress(INPUT_LS_D))
			{
				m_nSelect = (m_nSelect - 1 + 1) % 4 + 1;  bSelect = true;
			}

			if (m_bOption)
			{//�I�v�V����
			 //���E�Ő��l�̍X�V
				CCamera_Manager::Info &info = CManager::GetCamera()->GetInfo();

				if (pInputKey->GetTPress(DIK_RIGHT) ||
					pInputPad0->GetTPress(INPUT_RIGHT) || pInputPad0->GetTPress(INPUT_LS_R))
				{
					nPlus = 1;
				}
				if (pInputKey->GetTPress(DIK_LEFT) ||
					pInputPad0->GetTPress(INPUT_LEFT) || pInputPad0->GetTPress(INPUT_LS_L))
				{
					nPlus = -1;
				}

				if (pInputKey->GetTPress(DIK_BACKSPACE) ||
					pInputPad0->GetTPress(INPUT_B) || pInputPad0->GetTPress(INPUT_START))
				{//�߂�
					m_bOption = false;
					for (int nCount = 0; nCount < MAX_OPTION_SELECT; nCount++)
					{//Font�̏�����
						m_pFont[nCount]->Uninit();
						m_pFont[nCount] = NULL;
					}
					for (int nCount = 1; nCount <= 4; nCount++) { m_pScene2D[nCount]->BindDrawType(CScene::DRAW_TYPE_NORMAL); }
					CCamera_Manager::Save();
					CManager::GetSound()->Play(CSound::LABEL_LOCKCANSEL);
					return;
				}

				if (nPlus != 0)
				{//���͂��ꂽ
					CManager::GetSound()->Play(CSound::LABEL_CURSOR);
					switch (m_nSelect)
					{
					case 1: info.nSpeedY[m_nNumber] += nPlus; break;
					case 2: info.nSpeedX[m_nNumber] += nPlus; break;
					case 3: info.bReturnY[m_nNumber] = (info.bReturnY[m_nNumber] ? false : true); break;
					case 4: info.bReturnX[m_nNumber] = (info.bReturnX[m_nNumber] ? false : true); break;
					}
					if (info.nSpeedY[m_nNumber] > MAX_CAMERA_SPEED) { info.nSpeedY[m_nNumber] = MAX_CAMERA_SPEED; }
					if (info.nSpeedY[m_nNumber] < 1) { info.nSpeedY[m_nNumber] = 1; }
					if (info.nSpeedX[m_nNumber] > MAX_CAMERA_SPEED) { info.nSpeedX[m_nNumber] = MAX_CAMERA_SPEED; }
					if (info.nSpeedX[m_nNumber] < 1) { info.nSpeedX[m_nNumber] = 1; }
				}
				//�߂���ǉ�
				wsprintf(&aStr[0], "���E���񑬓x  < %d >", info.nSpeedY[m_nNumber]);
				m_pFont[0]->SetFont(&aStr[0], -1);
				wsprintf(&aStr[0], "�㉺���񑬓x   < %d >", info.nSpeedX[m_nNumber]);
				m_pFont[1]->SetFont(&aStr[0], -1);
				wsprintf(&aStr[0], "���E���]   < %s >", (info.bReturnY[m_nNumber] ? "�L��" : "����"));
				m_pFont[2]->SetFont(&aStr[0], -1);
				wsprintf(&aStr[0], "�㉺���]   < %s >", (info.bReturnX[m_nNumber] ? "�L��" : "����"));
				m_pFont[3]->SetFont(&aStr[0], -1);
			}
			else
			{//�I�v�V�����łȂ�
				if (pInputKey->GetTrigger(DIK_RETURN) || pInputPad0->GetTrigger(INPUT_A))
				{
					CManager::GetSound()->Play(CSound::LABEL_RETURN);
					if (m_nSelect == 1) { bPause = false; }
					else if (m_nSelect == 2) { CRenderDraw::SetFade(CManager::MODE_GAME, CRenderDraw::FADE_NORMAL, CRenderDraw::STATE_FADE_IN); CScene::GetbPause() = false; return; }
					else if (m_nSelect == 3) { CRenderDraw::SetFade(CManager::MODE_CHARSELECT, CRenderDraw::FADE_NORMAL, CRenderDraw::STATE_FADE_IN); CScene::GetbPause() = false; return; }
					else if (m_nSelect == 4)
					{//�I�v�V�������J��
						m_bOption = true; bSelect = true; m_nSelect = 1;
						for (int nCount = 1; nCount <= 4; nCount++) { m_pScene2D[nCount]->BindDrawType(CScene::DRAW_TYPE_NO); }
						for (int nCount = 0; nCount < MAX_OPTION_SELECT; nCount++)
						{
							if (SceneCreate(m_pFont[nCount], PAUSE_PRIORITY))
							{
								m_pFont[nCount]->Set(RECT{ 600, nCount * 100 + 200, SCREEN_WIDTH, SCREEN_HEIGHT }, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f)
									, "", 1, DT_LEFT, -1, true, CFont::STATE_NONE);
							}
						}
					}//�I�v�V�����J��
				}//�I�v�V������ԂłȂ�
			}

			if (!bPause)
			{//�|�[�Y���I������
				CScene::GetbPause() = false;

				for (int nCount = 0; nCount < MAX_GAME_PAUSE; nCount++)
				{//�S�|�[�Y�̔j��
					if (m_pScene2D[nCount] != NULL)
					{//��������Ă���΍폜
						m_pScene2D[nCount]->Uninit();
						m_pScene2D[nCount] = NULL;
					}
				}
			}
			else if (bSelect)
			{//��Ԃ̍X�V
			 //CSceneAnim2D *p2DAnim;
				CManager::GetSound()->Play(CSound::LABEL_CURSOR);
				for (int nCount = 1; nCount <= 4; nCount++)
				{
					if (m_nSelect == nCount)
					{ //�I������Ă���
						m_pScene2D[nCount]->GetState() = CScene2D::STATE_BIG;
					}
					else
					{ //�I������ĂȂ�
						m_pScene2D[nCount]->GetState() = CScene2D::STATE_SMALL;
					}
				}
				m_pScene2D[5]->SetPosition(m_pScene2D[m_nSelect]->GetPosition() + D3DXVECTOR3(-GAME_PAUSE_LOGOX * 1.5f, 0.0f, 0.0f));
				////���G�t�F�N�g
				//if (SceneCreate(p2DAnim, PAUSE_PRIORITY))
				//{
				//	p2DAnim->Set(m_pScene2D[m_nSelect]->GetPosition()[0] + D3DXVECTOR3(0.0f, 0.0f, 0.0f), 500.0f, 200.0f, D3DX_PI, 0, 3, 3, 3, 0.0f, CScene2D::STATE_FADEIN,
				//		CSceneAnim3D::ANIMATION_NORMAL, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f), CScene::TEX_MAX);
				//	p2DAnim->BindDrawType(CScene::DRAW_TYPE_OVERLAY);
				//}
			}
		}
	}//�t�F�[�h�m�F

}