//=============================================================================
//
// �{�X�̃~�T�C������ [projectile.h]
// Author : Yuto Kodama
//
//=============================================================================
#ifndef _PROJECTILE_H_
#define _PROJECTILE_H_
#include "SceneModel.h"

#define PROJECTILE_ACCELERATE (1.005f);	//�����x�{��

class CProjectile : public CSceneModel
{
public:
	typedef enum
	{
		P_MODEL_MISSILE = 0,
		P_MODEL_METEOR,
		MODEL_MAX
	}PROJECTILE_MODEL;

	CProjectile(int nPrioryity = MODEL_PRIORITY) : CSceneModel::CSceneModel(nPrioryity) {};
	~CProjectile() {};
	void	Set(PROJECTILE_MODEL model,D3DXVECTOR3 pos,D3DXVECTOR3 rot,float fMoveSpeed,int nLife,bool bAccel);
	void	Uninit(void);
	void	Update(void);
	void	Draw(void);

private:
	PROJECTILE_MODEL m_Model;
	D3DXVECTOR3 m_PosOld;		//�ߋ����W
	D3DXVECTOR3 m_Move;			//�ړ���
	D3DXVECTOR3 m_Rot;			//�p�x
	float m_fSpeed;				//���x
	int m_nLife;				//�̗�
	bool m_bAccel;				//�������邩
};

#endif // !_PROJECTILE_H_
