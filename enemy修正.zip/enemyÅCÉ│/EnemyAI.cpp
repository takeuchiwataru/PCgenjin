//=============================================================================
//
// "�G001"�GAI�̃x�[�X���� [EnemyAI.cpp] {CEnemyAIBase}
// Author : Yuto Kodama
//
//=============================================================================
#include "EnemyAI.h"
#include "renderer.h"
#include "manager.h"
#include "player.h"
#include "enemy.h"

//==============================================================
// ����������{CEnemyAIBase}
//==============================================================
void CEnemyAIBase::Init(CEnemy* pThis)
{
	m_pThisEnemy = pThis;
}

//==============================================================
// AI��������{CEnemyAIBase}
//==============================================================
CEnemyAIBase* CEnemyAIBase::Create(ENEMY_TYPE Etype, CEnemy* pThis)
{
	CEnemyAIBase* pAIBase = NULL;
	if (pAIBase == NULL)
	{
		switch (Etype)
		{
		case TYPE_NORMAL:
			pAIBase = new CEnemyAI_Normal;
			break;
		case TYPE_SLEEP:
			pAIBase = new CEnemyAI_Sleep;
			break;
		case TYPE_TRAP:
			pAIBase = new CEnemyAI_TrapFlower;
			break;
		case TYPE_SIGNBOARD:
			pAIBase = new CEnemyAI_SignBoard;
			break;
		case TYPE_STAGBEETLE:
			pAIBase = new CEnemyAI_StagBeetle;
			break;
		case TYPE_BOSS:
			break;
		}
		if (pAIBase != NULL)
		{
			pAIBase->Init(pThis);
		}
	}
	return pAIBase;
}

//==============================================================
// �p�x�v�Z����{CEnemyAIBase}
//==============================================================
float CEnemyAIBase::PlayerHoming(void)
{
	D3DXVECTOR3 &PlayerPos = CManager::GetPlayer(0)->Getpos();		//�v���C���̍��W
	D3DXVECTOR3 &ThisPos = m_pThisEnemy->Getpos();					//���g�̍��W
																	//�U���p�̌����ݒ�
	float fHomingRot = atan2f(PlayerPos.x - ThisPos.x, PlayerPos.z - ThisPos.z) + D3DX_PI;
	if (fHomingRot > D3DX_PI)
	{
		fHomingRot -= D3DX_PI * 2.0f;
	}
	else if (fHomingRot < -D3DX_PI)
	{
		fHomingRot += D3DX_PI * 2.0f;
	}

	//�������ɕ␳����
	if ((int)((fHomingRot) / fabs(fHomingRot)) == 1)
	{//������+�����Ȃ�
		fHomingRot = D3DX_PI * 0.5f;
	}
	else
	{//-�����Ȃ�
		fHomingRot = -D3DX_PI * 0.5f;
	}
	return fHomingRot;
}
//=============================================================================
//
// "�G001"��{�GAI�̏��� [EnemyAI.cpp] {CEnemyAI_Normal}
// Author : Yuto Kodama
//
//=============================================================================

//*****************************************************************************
// �}�N����`
//*****************************************************************************
#define ATTACK_INTERVAL (30)			//�U���Ԋu
#define ATTACK_LENGTH   (300.0f)		//�U���͈�

//==============================================================
// ����������{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::Init(CEnemy* pThis) {

	CEnemyAIBase::Init(pThis);
	//�����l�ݒ�
	m_vecLeapPos[0] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vecLeapPos[1] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_nNumLeap = 0;
	m_nCntAttackInterval = 0;
	m_AItype = TYPE_NORMAL;

}

//==============================================================
// �I������{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_Normal}
//==============================================================
bool CEnemyAI_Normal::AIUpdate(void) {
	if (m_pThisEnemy != NULL)
	{
		bool bMove = true;
		D3DXVECTOR3 &PlayerPos = CManager::GetPlayer(0)->Getpos();		//�v���C���̍��W
		D3DXVECTOR3 &ThisPos = m_pThisEnemy->Getpos();					//���g�̍��W
		float fResult = 0.0f;
		//�ړ��ʂ̔{���ݒ�
		m_pThisEnemy->GetMoveScaling() = 0.25f;

		//�ړ�����
		if (m_nCntAttackInterval == 0)
		{
			if (m_pThisEnemy->GetnNumMotion(1) != 2)
			{
				fResult = CalMoveVector(NULL, ThisPos) + D3DX_PI;
			}
			m_pThisEnemy->SetNextMotion(1);
		}
		else { bMove = false; }

		//�U���p�̌����ݒ�
		float fAttackRot = PlayerHoming();

		//�U������
		if (sqrtf((PlayerPos.x - ThisPos.x) * (PlayerPos.x - ThisPos.x) +
			(PlayerPos.y - ThisPos.y) * (PlayerPos.y - ThisPos.y) +
			(PlayerPos.z - ThisPos.z) * (PlayerPos.z - ThisPos.z)) <= ATTACK_LENGTH)
		{
			if (m_pThisEnemy->GetnNumMotion(1) != 2)
			{
				fResult = fAttackRot;
				m_nCntAttackInterval++;
			}
		}
		else
		{
			m_nCntAttackInterval = 0;
		}

		if (m_nCntAttackInterval >= ATTACK_INTERVAL)
		{
			fResult = fAttackRot;
			m_pThisEnemy->SetNextMotion(2);

			m_nCntAttackInterval = 0;
		}

		//�ړ��ƍU���ŎZ�o�������ʂ���
		m_pThisEnemy->GetfRot() = fResult;

		return bMove;
	}

	return false;
}

//==============================================================
// �ړ��p�x�v�Z����{CEnemyAI_Normal}
//==============================================================
float CEnemyAI_Normal::CalMoveVector(float* pOut, D3DXVECTOR3 pos) {
	D3DXVECTOR3 posDest = m_vecLeapPos[m_nNumLeap];	//�ڕW
	float fRot = 0.0f;

	if (sqrtf((posDest.x - pos.x) * (posDest.x - pos.x) +
		(posDest.y - pos.y) * (posDest.y - pos.y) +
		(posDest.z - pos.z) * (posDest.z - pos.z)) >= 5.0f)
	{//�ڕW�Ƃ̋��������ȉ��Ȃ�
		fRot = atan2f(posDest.x - pos.x, posDest.z - pos.z);
	}
	else
	{
		m_nNumLeap = (m_nNumLeap + 1) % 2;
	}

	if (pOut != NULL) { *pOut = fRot; }//���ʂ��i�[

	return fRot;
}

//==============================================================
// �ڕW�n�_�ݒ菈��{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::SetVecLeapPos(D3DXVECTOR3 start, D3DXVECTOR3 goal) {
	m_vecLeapPos[0] = start;
	m_vecLeapPos[1] = goal;
}
//==============================================================
// ��������{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::DamageReaction(void)
{
	//�����Ă�����Ƌt�ɐ�����΂�
	float fRot = m_pThisEnemy->GetfRot();
	m_pThisEnemy->Getmove() += D3DXVECTOR3(sinf(fRot) * 13.0f, 11.0f, cosf(fRot) * 13.0f);
}

//=============================================================================
//
// "�G002"�����GAI�̏��� [EnemyAI.cpp] {CEnemyAI_Sleep}
// Author : Yuto Kodama
//
//=============================================================================

//==============================================================
// ����������{CEnemyAI_Sleep}
//==============================================================
void CEnemyAI_Sleep::Init(CEnemy* pThis) {
	CEnemyAIBase::Init(pThis);
	m_nCntSleepInterval = 0;
	m_AItype = TYPE_SLEEP;

}

//==============================================================
// �I������{CEnemyAI_Sleep}
//==============================================================
void CEnemyAI_Sleep::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_Sleep}
//==============================================================
bool CEnemyAI_Sleep::AIUpdate(void) {

	if (m_pThisEnemy != NULL)
	{
		m_pThisEnemy->GetMoveScaling() = 0.0f;	//�ړ������Ȃ�����
		m_pThisEnemy->SetNextMotion(0);			//�������[�V�����ɂ���
	}

	return false;
}

//=============================================================================
//
// "�G003"�g���b�v�t�����[AI�̏��� [EnemyAI.cpp] {CEnemyAI_TrapFlower}
// Author : Yuto Kodama
//
//=============================================================================
#define JUMP_HEIGHT     (6.5f)		//�W�����v���̈ړ���
#define HIGHJUMP_HEIGHT (11.5f)		//��W�����v���̈ړ���

//==============================================================
// ����������{CEnemyAI_TrapFlower}
//==============================================================
void CEnemyAI_TrapFlower::Init(CEnemy* pThis) {
	CEnemyAIBase::Init(pThis);
	m_AItype = TYPE_TRAP;
	m_nCntHighJump = 0;

	if (m_pThisEnemy != NULL)
	{
		m_pThisEnemy->GetbJump() = true;
	}
}

//==============================================================
// �I������{CEnemyAI_TrapFlower}
//==============================================================
void CEnemyAI_TrapFlower::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_TrapFlower}
//==============================================================
bool CEnemyAI_TrapFlower::AIUpdate(void) {
	D3DXVECTOR3 move = m_pThisEnemy->Getmove();
	if (m_pThisEnemy != NULL)
	{
		m_pThisEnemy->SetNextMotion(1);
		m_pThisEnemy->GetMoveScaling() = 0.2f;	//�ړ��𐧌�����(�e�X�g�p)
		//�ړ��p�̌����ݒ�
		float fMoveRot = PlayerHoming();
		if (fMoveRot > 0.0f) { move.x -= 1.0f; }
		else { move.x += 1.0f; }

		if (m_pThisEnemy->Getpos().y <= m_fOrgJumpHeight)
		{//���n���Ă�����
			m_pThisEnemy->GetbJump() = true;
		}

		if (m_pThisEnemy->GetbJump() == true)
		{

			if (m_nCntHighJump != m_nHighJumpInterval - 1)
			{
				m_pThisEnemy->Getmove() = D3DXVECTOR3(move.x, JUMP_HEIGHT, move.z);
				move = D3DXVECTOR3(move.x, JUMP_HEIGHT, move.z);
			}
			else
			{
				m_pThisEnemy->Getmove() = D3DXVECTOR3(move.x, HIGHJUMP_HEIGHT, move.z);
				move = D3DXVECTOR3(move.x, HIGHJUMP_HEIGHT, move.z);
			}

			m_pThisEnemy->GetbJump() = false;
			m_nCntHighJump = (m_nCntHighJump + 1) % (m_nHighJumpInterval);
		}

		//��W�����v���ɉ���ʂ蔲���₷���悤�ɏd�͂𒲐�����
		int nSign = (int)((move.y) / fabs(move.y)) * -1;	//�d�͒����p�̕����ݒ�
		m_pThisEnemy->Getmove().y += (0.11f * nSign);
	}


	return true;
}

//==============================================================
// ��������{CEnemyAI_TrapFlower}
//==============================================================
void CEnemyAI_TrapFlower::DamageReaction(void)
{
	//�����Ă�����Ƌt�ɐ�����΂�
	float fRot = m_pThisEnemy->GetfRot();
	m_pThisEnemy->Getmove() += D3DXVECTOR3(sinf(fRot) * 13.0f, 11.0f, cosf(fRot) * 13.0f);
}

//=============================================================================
//
// "�G004"�J���o�������GAI�̏��� [EnemyAI.cpp] {CEnemyAI_SignBoard}
// Author : Yuto Kodama
//
//=============================================================================

//==============================================================
// ����������{CEnemyAI_SignBoard}
//==============================================================
void CEnemyAI_SignBoard::Init(CEnemy* pThis) {
	CEnemyAIBase::Init(pThis);
	m_AItype = TYPE_SIGNBOARD;

}

//==============================================================
// �I������{CEnemyAI_SignBoard}
//==============================================================
void CEnemyAI_SignBoard::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_SignBoard}
//==============================================================
bool CEnemyAI_SignBoard::AIUpdate(void) {
	if (m_pThisEnemy != NULL)
	{
		m_pThisEnemy->SetNextMotion(0);		//�j���[�g�������[�V�����ɂ���
	}
	return false;
}

//==============================================================
// ��������{CEnemyAI_SignBoard}
//==============================================================
void CEnemyAI_SignBoard::DamageReaction(void)
{
	float fRot = 0.0f;
	switch (CManager::GetMode())
	{
	case CManager::MODE_SELECT:
		break;
	default:
		fRot = m_pThisEnemy->GetfRot();
		break;
	}
	m_pThisEnemy->Getmove() += D3DXVECTOR3(sinf(fRot) * 13.0f, 10.0f, cosf(fRot) * 13.0f);
}
//=============================================================================
//
// "�G005"�N���K�^�GAI�̏��� [EnemyAI.cpp] {CEnemyAI_StagBeetle}
// Author : Yuto Kodama
//
//=============================================================================

//==============================================================
// ����������{CEnemyAI_StagBeetle}
//==============================================================
void CEnemyAI_StagBeetle::Init(CEnemy* pThis)
{
	CEnemyAIBase::Init(pThis);
}

//==============================================================
// �I������{CEnemyAI_StagBeetle}
//==============================================================
void CEnemyAI_StagBeetle::Uninit(void)
{

}

//==============================================================
// �X�V����{CEnemyAI_StagBeetle}
//==============================================================
bool CEnemyAI_StagBeetle::AIUpdate(void)
{
	return true;
}