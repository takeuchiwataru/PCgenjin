//=============================================================================
//
// "�G001"��{�GAI�̏��� [EnemyAI.cpp] {CEnemyAI_Normal}
// Author : Yuto Kodama
//
//=============================================================================
#include "EnemyAI.h"
#include "renderer.h"
#include "manager.h"
#include "player.h"
#include "enemy.h"

//*****************************************************************************
// �}�N����`
//*****************************************************************************
#define ATTACK_INTERVAL (90)			//�U���Ԋu
#define ATTACK_LENGTH   (300.0f)		//�U���͈�

//==============================================================
// ����������{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::Init(void) {

	//�����l�ݒ�
	m_vecLeapPos[0] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vecLeapPos[1] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_nNumLeap = 0;
	m_nCntAttackInterval = 0;
	m_AItype = TYPE_NORMAL;
}

//==============================================================
// �I������{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_Normal}
//==============================================================
bool CEnemyAI_Normal::AIUpdate(CEnemy* pThis) {
	if (pThis != NULL)
	{
		bool bMove = true;
		D3DXVECTOR3 &PlayerPos = CManager::GetPlayer(0)->Getpos();		//�v���C���̍��W
		D3DXVECTOR3 &ThisPos = pThis->Getpos();							//���g�̍��W

																		//�ړ��ʂ̔{���ݒ�
		pThis->GetMoveScaling() = 0.25f;
		//�ړ�����
		if (m_nCntAttackInterval == 0)
		{
			pThis->SetNextMotion(1);

			pThis->GetfRot() = CalMoveVector(NULL, ThisPos) + D3DX_PI;
		}
		else { bMove = false; }

		//�U������
		if (sqrtf((PlayerPos.x - ThisPos.x) * (PlayerPos.x - ThisPos.x) +
			(PlayerPos.y - ThisPos.y) * (PlayerPos.y - ThisPos.y) +
			(PlayerPos.z - ThisPos.z) * (PlayerPos.z - ThisPos.z)) <= ATTACK_LENGTH)
		{
			if (pThis->GetnNumMotion(1) != 2)
			{
				pThis->GetfRot() = atan2f(PlayerPos.x - ThisPos.x, PlayerPos.z - ThisPos.z) + D3DX_PI;
				m_nCntAttackInterval++;
			}
		}
		else
		{
			m_nCntAttackInterval = 0;
		}

		if (m_nCntAttackInterval >= ATTACK_INTERVAL)
		{
			pThis->GetfRot() = atan2f(PlayerPos.x - ThisPos.x, PlayerPos.z - ThisPos.z) + D3DX_PI;
			pThis->SetNextMotion(2);

			m_nCntAttackInterval = 0;
		}
		return bMove;
	}

	return false;
}

//==============================================================
// �ړ��p�x�v�Z����{CEnemyAI_Normal}
//==============================================================
float CEnemyAI_Normal::CalMoveVector(float* pOut, D3DXVECTOR3 pos) {
	D3DXVECTOR3 posDest = m_vecLeapPos[m_nNumLeap];	//�ڕW
	float fRot = 0.0f;

	if (sqrtf((posDest.x - pos.x) * (posDest.x - pos.x) +
		(posDest.y - pos.y) * (posDest.y - pos.y) +
		(posDest.z - pos.z) * (posDest.z - pos.z)) >= 5.0f)
	{//�ڕW�Ƃ̋��������ȉ��Ȃ�
		fRot = atan2f(posDest.x - pos.x, posDest.z - pos.z);
	}
	else
	{
		m_nNumLeap = (m_nNumLeap + 1) % 2;
	}

	if (pOut != NULL) { *pOut = fRot; }//���ʂ��i�[

	return fRot;
}

//==============================================================
// �ڕW�n�_�ݒ菈��{CEnemyAI_Normal}
//==============================================================
void CEnemyAI_Normal::SetVecLeapPos(D3DXVECTOR3 start, D3DXVECTOR3 goal) {
	m_vecLeapPos[0] = start;
	m_vecLeapPos[1] = goal;
}

//=============================================================================
//
// "�G002"�����GAI�̏��� [EnemyAI.cpp] {CEnemyAI_Sleep}
// Author : Yuto Kodama
//
//=============================================================================

//==============================================================
// ����������{CEnemyAI_Sleep}
//==============================================================
void CEnemyAI_Sleep::Init(void) {
	m_nCntSleepInterval = 0;
	m_bSlideFlag = false;
	m_AItype = TYPE_SLEEP;
}

//==============================================================
// �I������{CEnemyAI_Sleep}
//==============================================================
void CEnemyAI_Sleep::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_Sleep}
//==============================================================
bool CEnemyAI_Sleep::AIUpdate(CEnemy* pThis) {

	return false;
}

//=============================================================================
//
// "�G003"�g���b�v�t�����[AI�̏��� [EnemyAI.cpp] {CEnemyAI_TrapFlower}
// Author : Yuto Kodama
//
//=============================================================================

//==============================================================
// ����������{CEnemyAI_TrapFlower}
//==============================================================
void CEnemyAI_TrapFlower::Init(void) {
	m_AItype = TYPE_TRAP;
}

//==============================================================
// �I������{CEnemyAI_TrapFlower}
//==============================================================
void CEnemyAI_TrapFlower::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_TrapFlower}
//==============================================================
bool CEnemyAI_TrapFlower::AIUpdate(CEnemy* pThis) {
	return true;
}

//=============================================================================
//
// "�G004"�J���o�������GAI�̏��� [EnemyAI.cpp] {CEnemyAI_SignBoard}
// Author : Yuto Kodama
//
//=============================================================================

//==============================================================
// ����������{CEnemyAI_SignBoard}
//==============================================================
void CEnemyAI_SignBoard::Init(void) {
	m_AItype = TYPE_SIGNBOARD;
}

//==============================================================
// �I������{CEnemyAI_SignBoard}
//==============================================================
void CEnemyAI_SignBoard::Uninit(void) {

}

//==============================================================
// �X�V����{CEnemyAI_SignBoard}
//==============================================================
bool CEnemyAI_SignBoard::AIUpdate(CEnemy* pThis) {
	return false;
}