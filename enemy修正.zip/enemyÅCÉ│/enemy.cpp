//=============================================================================
//
// �G�l�~�[���� [enemy.cpp]{CEnemy}
// Author : Ryo Sugimoto
// Editor : Yuto Kodama
//
//=============================================================================
#include "main.h"
#include "motion.h"
#include "enemy.h"
#include "player.h"
#include "bullet.h"
#include "camera.h"
#include "Game.h"
#include "Survival.h"
#include "renderer.h"
#include "manager.h"

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************

//*****************************************************************************
// �ÓI�����o�ϐ�
//*****************************************************************************

//==================================================================================================//
//    * �G�l�~�[�̃Z�b�g�֐� *
//==================================================================================================//
void CEnemy::Set(D3DXVECTOR3 pos, D3DXVECTOR3 rot, CMotion::TYPE Mtype, TYPE type, CEnemyAIBase::ENEMY_TYPE Etype)
{
	float fValue = (CManager::GetbDuo() ? 1.35f : 1.0f);
	CCharacter::Set(pos, rot, Mtype);
	m_Type = type;
	SetStatus();

	switch (m_Type)
	{
	case TYPE_VERSUS:
		SetObjType(OBJTYPE_BOSS);
		break;
	case TYPE_NONE:		GetfMaxLife() *= 0.06f * fValue; GetfLife() = GetfMaxLife();	break;
	case TYPE_GOBURINN:	GetfMaxLife() *= 0.1f  * fValue; GetfLife() = GetfMaxLife();	break;
	case TYPE_TITLE:	GetfMaxLife() *= 1.0f * fValue; GetfLife() = GetfMaxLife();		break;
	}

	//AI
	m_pEnemyAI = NULL;
	m_pEnemyAI = CEnemyAIBase::Create(Etype,this);
}
//=============================================================================
// �G�l�~�[�̏���������
//=============================================================================
HRESULT  CEnemy::Init(void)
{
	CCharacter::Init();
	tex = CScene::TEX_ENEMY_000;
	m_pTarget	= NULL;
	m_nCntFrame = 0;
	m_nMaxFrame = 0;
	m_fMove		= 0.0f;

	SetObjType(CScene::OBJTYPE_ENEMY);
	GetTeam() = CCharacter::TEAM_ENEMY;


	return S_OK;
}
//=============================================================================
// �G�l�~�[�̍X�V����
//=============================================================================
void	CEnemy::Update(void)
{
	CInputKeyboard	*pInputKey = CManager::GetInputKey();
	bool			bMove = false;
	D3DXVECTOR3 &m_pos = Getpos();

	//AI�̐���
	if (m_pEnemyAI != NULL)
	{
		bMove = m_pEnemyAI->AIUpdate();
	}

	//���[�V�����m�F�p
	if (pInputKey->GetPress(DIK_T))
	{
		D3DXVECTOR3 &pos = CManager::GetPlayer(0)->Getpos();
		SetNextMotion(1); bMove = true;
		GetfRot() = atan2f(pos.x - m_pos.x, pos.z - m_pos.z) + D3DX_PI;
	}
	if (pInputKey->GetPress(DIK_G)) { SetNextMotion(2); }
	if (pInputKey->GetPress(DIK_B)) { SetNextMotion(4); }
	if (pInputKey->GetPress(DIK_V)) { SetNextMotion(5); }
	if (pInputKey->GetPress(DIK_C)) { SetNextMotion(6); Dead(); GetfLife() = 0; }

	//�e�̍X�V
	CCharacter::Update(bMove);
}
//=============================================================================
// �G�l�~�[�̕`�揈��
//=============================================================================
void	CEnemy::Draw(void)
{
	if (CManager::GetCamera()->GetInfo().pCamera->GetnNumCamera() == 0) { m_bDraw = false; }
	if (CManager::GetCamera()->DrawCheck(Getpos(), 100.0f))
	{
		LPDIRECT3DDEVICE9	&pDevice = CManager::GetRenderer()->GetDevice();	//�f�o�C�X�̎擾

		m_bDraw = true;
		pDevice->SetTexture(0, CScene::Load(tex));
		CCharacter::Draw();
		pDevice->SetTexture(0, NULL);

		CCharacter::DrawGage();
	}
}
//=============================================================================
// �G�l�~�[�̎��S����
//=============================================================================
void	CEnemy::Dead(void)
{
	if (m_pEnemyAI != NULL)
	{
		m_pEnemyAI->Uninit();

		delete m_pEnemyAI;
		m_pEnemyAI = NULL;
	}

	if (CManager::GetMode() == CManager::MODE_SURVIVAL) { CManager::GetSurvival()->DeadEnemy(); }
	if (CManager::GetMode() == CManager::MODE_PRACTICE) { GetfLife() = 1.0f; }
	CCharacter::Dead();
}
//=============================================================================
// �G�l�~�[�̏�������
//=============================================================================
void	CEnemy::Over(void)
{
	if (m_pEnemyAI != NULL)
	{
		m_pEnemyAI->Uninit();

		delete m_pEnemyAI;
		m_pEnemyAI = NULL;
	}

	switch (m_Type)
	{
	case TYPE_NONE: break;
	case TYPE_TITLE: CManager::GetGame()->SetState(CGame::STATE_CLEAR); break;
	}
	CCharacter::Over();
}

//=============================================================================
// �G�l�~�[��AI�ݒ菈��
//=============================================================================
void CEnemy::SetAIState(CEnemyAIBase::ENEMY_TYPE type, D3DXVECTOR3 start, D3DXVECTOR3 goal){	//�ʏ�G��AI
	if (type == CEnemyAIBase::TYPE_NORMAL)
	{
		if (m_pEnemyAI != NULL && m_pEnemyAI->GetAItype() == CEnemyAIBase::TYPE_NORMAL)
		{
			CEnemyAI_Normal* pAI = (CEnemyAI_Normal*)m_pEnemyAI;
			pAI->SetVecLeapPos(start, goal);
		}
	}
}

void CEnemy::SetAIState(CEnemyAIBase::ENEMY_TYPE type, float fOrgHeight, int nJumpInterval) {    //�g���b�v�t�����[
	if (type == CEnemyAIBase::TYPE_TRAP)
	{
		if (m_pEnemyAI != NULL && m_pEnemyAI->GetAItype() == CEnemyAIBase::TYPE_TRAP)
		{
			CEnemyAI_TrapFlower* pAI = (CEnemyAI_TrapFlower*)m_pEnemyAI;
			pAI->GetOrgJumpHeight() = fOrgHeight;
			pAI->GetHighJumpInterval() = nJumpInterval;
		}
	}
}


