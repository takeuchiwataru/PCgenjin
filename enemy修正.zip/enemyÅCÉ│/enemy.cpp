//=============================================================================
//
// �G�l�~�[���� [enemy.cpp]{CEnemy}
// Author : Ryo Sugimoto
// Editor : Yuto Kodama
//
//=============================================================================
#include "main.h"
#include "motion.h"
#include "enemy.h"
#include "player.h"
#include "bullet.h"
#include "camera.h"
#include "Game.h"
#include "renderer.h"
#include "manager.h"

#define ENEMYDATA ("data/TEXT/EnemyLoad000.txt")		//�G���t�@�C���̃A�h���X

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************

//*****************************************************************************
// �ÓI�����o�ϐ�
//*****************************************************************************

//==================================================================================================//
//    * �G�l�~�[�̃Z�b�g�֐� *
//==================================================================================================//
void CEnemy::Set(D3DXVECTOR3 pos, D3DXVECTOR3 rot, CMotion::TYPE Mtype, CEnemyAIBase::ENEMY_TYPE Etype)
{
	float fValue = (CManager::GetbDuo() ? 1.35f : 1.0f);
	CCharacter::Set(pos, rot, Mtype);
	SetStatus();

	GetfMaxLife() *= 0.06f * fValue; GetfLife() = GetfMaxLife();
	//AI
	m_pEnemyAI = NULL;
	m_pEnemyAI = CEnemyAIBase::Create(Etype,this);
}

//==================================================================================================//
//    * �G�l�~�[�̓ǂݍ��݊֐� *
//==================================================================================================//
HRESULT CEnemy::Load(void)
{
	FILE* pFile = NULL;		// �t�@�C���|�C���^
	char ReadText[256];		// �ǂݍ��񂾕���������Ă���
	char HeadText[256];		// ��r�p
	char DustBox[256];		// �g�p���Ȃ����̂����Ă���

	//�ꎞ�f�[�^�x�[�X
	std::vector<ENEMY_LOAD_STATE> LoadState; LoadState.clear();
	std::vector<CEnemyAI_Normal::NORMAL_AI_LOAD_STATE> NormalAI; NormalAI.clear();
	std::vector<CEnemyAI_TrapFlower::TRAP_AI_LOAD_STATE> TrapAI; TrapAI.clear();


	ENEMY_LOAD_STATE OneState;
	CEnemyAI_Normal::NORMAL_AI_LOAD_STATE OneAI_Normal;
	CEnemyAI_TrapFlower::TRAP_AI_LOAD_STATE OneAI_Trap;

	//�t�@�C���I�[�v��
	pFile = fopen(ENEMYDATA, "r");

	if (pFile != NULL)
	{//�t�@�C�����J����Ă����
		while (strcmp(HeadText, "START_LOAD") != 0)
		{// "START_LOAD" ���ǂݍ��܂��܂ŌJ��Ԃ��������ǂݎ��
			fgets(ReadText, sizeof(ReadText), pFile);
			sscanf(ReadText, "%s", &HeadText);
		}
		if (strcmp(HeadText, "START_LOAD") == 0)
		{// "START_LOAD" ���ǂݎ�ꂽ�ꍇ�A�����J�n
			while (strcmp(HeadText, "END_LOAD") != 0)
			{// "END_LOAD" ���ǂݍ��܂��܂ŌJ��Ԃ��������ǂݎ��
				fgets(ReadText, sizeof(ReadText), pFile);
				sscanf(ReadText, "%s", &HeadText);

				if (strcmp(HeadText, "\n") == 0)
				{// ������̐擪�� [\n](���s) �̏ꍇ�������Ȃ�

				}
				else if (strcmp(HeadText, "START_DATA") == 0)
				{// "START_DATA" ���ǂݎ�ꂽ�ꍇ
					while (strcmp(HeadText, "END_DATA") != 0)
					{// "END_DATA" ���ǂݍ��܂��܂ŌJ��Ԃ��������ǂݎ��
						fgets(ReadText, sizeof(ReadText), pFile);
						sscanf(ReadText, "%s", &HeadText);

						if (strcmp(HeadText, "\n") == 0)
						{// ������̐擪�� [\n](���s) �̏ꍇ�������Ȃ�

						}
						else if (strcmp(HeadText, "POS") == 0)		//���W
						{
							sscanf(ReadText, "%s %c %f %f %f",
								&DustBox, &DustBox,
								&OneState.pos.x,
								&OneState.pos.y,
								&OneState.pos.z);
						}
						else if (strcmp(HeadText, "ROT") == 0)		//�p�x
						{
							sscanf(ReadText, "%s %c %f %f %f",
								&DustBox, &DustBox,
								&OneState.rot.x,
								&OneState.rot.y,
								&OneState.rot.z);
						}
						else if (strcmp(HeadText, "MOTION") == 0)	//���[�V�����^�C�v
						{
							sscanf(ReadText, "%s %c %d",
								&DustBox, &DustBox,
								&(CMotion::TYPE)OneState.MotionType);
						}
						else if (strcmp(HeadText, "AI") == 0)		//AI�^�C�v
						{
							sscanf(ReadText, "%s %c %d",
								&DustBox, &DustBox,
								&(CEnemyAIBase::ENEMY_TYPE)OneState.AIType);
						}
						else if (strcmp(HeadText, "START_POS") == 0)//�n�_���W(NormalAI��p)
						{
							if (OneState.AIType == CEnemyAIBase::TYPE_NORMAL)
							{
								sscanf(ReadText, "%s %c %f %f %f",
									&DustBox, &DustBox,
									&OneAI_Normal.StartPos.x,
									&OneAI_Normal.StartPos.y,
									&OneAI_Normal.StartPos.z);
							}
						}
						else if (strcmp(HeadText, "GOAL_POS") == 0)//�I�_���W(NormalAI��p)
						{
							if (OneState.AIType == CEnemyAIBase::TYPE_NORMAL)
							{
								sscanf(ReadText, "%s %c %f %f %f",
									&DustBox, &DustBox,
									&OneAI_Normal.GoalPos.x,
									&OneAI_Normal.GoalPos.y,
									&OneAI_Normal.GoalPos.z);
							}
						}
						else if (strcmp(HeadText, "ORG_HEIGHT") == 0)//��{�̍���(TrapAI��p)
						{
							if (OneState.AIType == CEnemyAIBase::TYPE_TRAP)
							{
								sscanf(ReadText, "%s %c %f",
									&DustBox, &DustBox,
									&OneAI_Trap.fOrgHeight);
							}
						}
						else if (strcmp(HeadText, "JUMP_INTERVAL") == 0)//�W�����v�̊Ԋu(TrapAI��p)
						{
							if (OneState.AIType == CEnemyAIBase::TYPE_TRAP)
							{
								sscanf(ReadText, "%s %c %d",
									&DustBox, &DustBox,
									&OneAI_Trap.nHighJump);
							}
						}
					}

					//��̃f�[�^��ǂݍ��񂾌�,�ꎞ�f�[�^�x�[�X�Ɋi�[
					LoadState.emplace_back(OneState);
					switch (OneState.AIType)
					{
					case CEnemyAIBase::TYPE_NORMAL: NormalAI.emplace_back(OneAI_Normal); break;
					case CEnemyAIBase::TYPE_TRAP: TrapAI.emplace_back(OneAI_Trap); break;
					}
				}
			}
		}

		//�t�@�C���N���[�Y
		if (pFile != NULL)
		{
			fclose(pFile);
			pFile = NULL;
		}

		//�G�̐���
		int nNumEnemy = LoadState.size();
		int nCntNormal = 0, nCntTrap = 0;
		CEnemy* pEnemy = NULL;
		for (int nCntEnemy = 0; nCntEnemy < nNumEnemy; nCntEnemy++)
		{
			if (SceneCreate(pEnemy, CHAR_PRIORITY))
			{
				pEnemy->Set(LoadState[nCntEnemy].pos, LoadState[nCntEnemy].rot, LoadState[nCntEnemy].MotionType, LoadState[nCntEnemy].AIType);
				switch (LoadState[nCntEnemy].AIType)
				{
				case CEnemyAIBase::TYPE_NORMAL: pEnemy->SetAIState(LoadState[nCntEnemy].AIType, NormalAI[nCntNormal].StartPos, NormalAI[nCntNormal].GoalPos); nCntNormal++; break;
				case CEnemyAIBase::TYPE_TRAP: pEnemy->SetAIState(LoadState[nCntEnemy].AIType, TrapAI[nCntTrap].fOrgHeight, TrapAI[nCntTrap].nHighJump); nCntTrap++; break;
				}
			}
		}


	}
	else
	{//�����ɓ�������G���[(���̃t�@�C�����Ȃ�or�J���Ȃ�)
		MessageBox(NULL, "�G�̏��t�@�C�����J���܂���ł����B", NULL, MB_OK);
		return S_FALSE;
	}

	return S_OK;
}
//==================================================================================================//
//    * �G�l�~�[�̏����o���֐� *
//==================================================================================================//
HRESULT CEnemy::Save(void)
{
	FILE* pFile = NULL;		// �t�@�C���|�C���^

	//�G�̊�{�����i�[
	std::vector<ENEMY_LOAD_STATE> SaveState;
	std::vector<CEnemyAI_Normal::NORMAL_AI_LOAD_STATE> NormalAI;
	std::vector<CEnemyAI_TrapFlower::TRAP_AI_LOAD_STATE> TrapAI;

	ENEMY_LOAD_STATE OneState;
	CEnemyAI_Normal::NORMAL_AI_LOAD_STATE OneAI_Normal;
	CEnemyAI_TrapFlower::TRAP_AI_LOAD_STATE OneAI_Trap;

	//�f�[�^�̕ۑ�
	CScene* pScene = NULL;
	pScene = CScene::GetTop(CHAR_PRIORITY);
	if (pScene != NULL)
	{
		do
		{
			CScene* pSceneNext = pScene->GetpNext();
			if (pScene->GetObjType() == OBJTYPE_ENEMY)
			{
				//���ʃf�[�^�̕ۑ�
				CEnemy* pEnemy = (CEnemy*)pScene;
				OneState.pos = pEnemy->Getpos();
				OneState.rot = pEnemy->Getrot();
				OneState.MotionType = pEnemy->GetType();
				OneState.AIType = pEnemy->GetAI()->GetAItype();

				SaveState.emplace_back(OneState);

				//AI���Ƃ̃f�[�^�ۑ�
				CEnemyAI_Normal* pAINormal = NULL;
				CEnemyAI_TrapFlower* pAITrap = NULL;
				switch (OneState.AIType)
				{
				case CEnemyAIBase::TYPE_NORMAL:
					pAINormal = (CEnemyAI_Normal*)pEnemy->GetAI();
					OneAI_Normal.StartPos = pAINormal->GetLeapPos(0);
					OneAI_Normal.GoalPos = pAINormal->GetLeapPos(1);
					NormalAI.emplace_back(OneAI_Normal);
					break;
				case CEnemyAIBase::TYPE_TRAP:
					pAITrap = (CEnemyAI_TrapFlower*)pEnemy->GetAI();
					OneAI_Trap.fOrgHeight = pAITrap->GetOrgJumpHeight();
					OneAI_Trap.nHighJump = pAITrap->GetHighJumpInterval();
					TrapAI.emplace_back(OneAI_Trap);
					break;
				}
			}
			pScene = pSceneNext;
		} while (pScene != NULL);
	}


	//�t�@�C���I�[�v��
	pFile = fopen(ENEMYDATA, "w");

	if (pFile != NULL)
	{
		fprintf(pFile, "//====================================================================================\n");
		fprintf(pFile, "//																					  \n");
		fprintf(pFile, "//	�G���[�h�p�e�L�X�g[EnemyLoad000.txt]											  \n");
		fprintf(pFile, "//	Author : Kodama Yuto(���� �D�l)													  \n");
		fprintf(pFile, "//	Editor :																		  \n");
		fprintf(pFile, "//																					  \n");
		fprintf(pFile, "//====================================================================================\n");

		int nNumEnemy = SaveState.size();
		int nCntNormal = 0, nCntTrap = 0;

			fprintf(pFile, "START_LOAD\n");
		for (int nCntEnemy = 0; nCntEnemy < nNumEnemy; nCntEnemy++)
		{
			fprintf(pFile, "	START_DATA\n");
			fprintf(pFile, "		POS = %.1f %.1f %.1f\n",SaveState[nCntEnemy].pos.x, SaveState[nCntEnemy].pos.y, SaveState[nCntEnemy].pos.z);
			fprintf(pFile, "		ROT = %.2f %.2f %.2f\n", SaveState[nCntEnemy].rot.x, SaveState[nCntEnemy].rot.y, SaveState[nCntEnemy].rot.z);
			fprintf(pFile, "		MOTION = %d\n",(int)SaveState[nCntEnemy].MotionType);
			fprintf(pFile, "		AI = %d\n", (int)SaveState[nCntEnemy].AIType);

			switch (SaveState[nCntEnemy].AIType)
			{
			case CEnemyAIBase::TYPE_NORMAL:
				fprintf(pFile, "		START_POS = %.1f %.1f %.1f\n",NormalAI[nCntNormal].StartPos.x, NormalAI[nCntNormal].StartPos.y, NormalAI[nCntNormal].StartPos.z);
				fprintf(pFile, "		GOAL_POS = %.1f %.1f %.1f\n", NormalAI[nCntNormal].GoalPos.x, NormalAI[nCntNormal].GoalPos.y, NormalAI[nCntNormal].GoalPos.z);
				nCntNormal++; break;
			case CEnemyAIBase::TYPE_TRAP:
				fprintf(pFile, "		ORG_HEIGHT = %.1f\n", TrapAI[nCntTrap].fOrgHeight);
				fprintf(pFile, "		JUMP_INTERVAL = %d\n", TrapAI[nCntTrap].nHighJump);
				nCntTrap++; break;
			}
			fprintf(pFile, "	END_DATA\n");
		}
			fprintf(pFile, "END_LOAD\n");

		//�t�@�C���N���[�Y
		if (pFile != NULL)
		{
			fclose(pFile);
			pFile = NULL;
		}
	}
	else
	{//�����ɓ�������G���[(���̃t�@�C�����Ȃ�or�J���Ȃ�)
		MessageBox(NULL, "�G�̏��t�@�C���ɏ������߂܂���ł����B", NULL, MB_OK);
		return S_FALSE;
	}

	return S_OK;
}

//=============================================================================
// �G�l�~�[�̏���������
//=============================================================================
HRESULT  CEnemy::Init(void)
{
	CCharacter::Init();
	m_pTarget	= NULL;
	m_nCntFrame = 0;
	m_nMaxFrame = 0;
	m_fMove		= 0.0f;

	SetObjType(CScene::OBJTYPE_ENEMY);
	GetTeam() = CCharacter::TEAM_ENEMY;

	return S_OK;
}
//=============================================================================
// �G�l�~�[�̍X�V����
//=============================================================================
void	CEnemy::Update(void)
{
	CInputKeyboard	*pInputKey = CManager::GetInputKey();
	bool			bMove = false;
	D3DXVECTOR3 &m_pos = Getpos();

	//AI�̐���
	if (m_pEnemyAI != NULL)
	{
		bMove = m_pEnemyAI->AIUpdate();
	}

	//���[�V�����m�F�p
	if (pInputKey->GetPress(DIK_T))
	{
		D3DXVECTOR3 &pos = CManager::GetPlayer(0)->Getpos();
		SetNextMotion(1); bMove = true;
		GetfRot() = atan2f(pos.x - m_pos.x, pos.z - m_pos.z) + D3DX_PI;
	}
	if (pInputKey->GetPress(DIK_G)) { SetNextMotion(2); }
	if (pInputKey->GetPress(DIK_B)) { SetNextMotion(4); }
	if (pInputKey->GetPress(DIK_V)) { SetNextMotion(5); }
	if (pInputKey->GetPress(DIK_C)) { SetNextMotion(6); Dead(); GetfLife() = 0; }

	//�e�̍X�V
	CCharacter::Update(bMove);
}
//=============================================================================
// �G�l�~�[�̕`�揈��
//=============================================================================
void	CEnemy::Draw(void)
{
	if (CManager::GetCamera()->GetInfo().pCamera->GetnNumCamera() == 0) { m_bDraw = false; }
	if (CManager::GetCamera()->DrawCheck(Getpos(), 100.0f))
	{
		LPDIRECT3DDEVICE9	&pDevice = CManager::GetRenderer()->GetDevice();	//�f�o�C�X�̎擾

		m_bDraw = true;
		CCharacter::Draw();
		pDevice->SetTexture(0, NULL);

		CCharacter::DrawGage();
	}
}
//=============================================================================
// �G�l�~�[�̃_���[�W����
//=============================================================================
bool	CEnemy::Damage(float fValue, CCharacter *&pChar)
{
	if (fValue > 0.0f)
	{
		SetCancelMotion(5);
		//SetNextMotion(5);//�_���[�W���[�V�����ɂ���

		//�����Ă�����Ƌt�ɐ�����΂�
		float fRot = GetfRot();
		Getmove() += D3DXVECTOR3(sinf(fRot) * 13.0f,11.0f,cosf(fRot) * 13.0f);
	}


	return CCharacter::Damage(fValue,pChar);
}

//=============================================================================
// �G�l�~�[�̎��S����
//=============================================================================
void	CEnemy::Dead(void)
{
	if (m_pEnemyAI != NULL)
	{
		m_pEnemyAI->Uninit();

		delete m_pEnemyAI;
		m_pEnemyAI = NULL;
	}

	if (CManager::GetMode() == CManager::MODE_PRACTICE) { GetfLife() = 1.0f; }
	CCharacter::Dead();
}
//=============================================================================
// �G�l�~�[�̏�������
//=============================================================================
void	CEnemy::Over(void)
{
	if (m_pEnemyAI != NULL)
	{
		m_pEnemyAI->Uninit();

		delete m_pEnemyAI;
		m_pEnemyAI = NULL;
	}

	CCharacter::Over();
}

//=============================================================================
// �G�l�~�[��AI�ݒ菈��
//=============================================================================
void CEnemy::SetAIState(CEnemyAIBase::ENEMY_TYPE type, D3DXVECTOR3 start, D3DXVECTOR3 goal){	//�ʏ�G��AI
	if (type == CEnemyAIBase::TYPE_NORMAL)
	{
		if (m_pEnemyAI != NULL && m_pEnemyAI->GetAItype() == CEnemyAIBase::TYPE_NORMAL)
		{
			CEnemyAI_Normal* pAI = (CEnemyAI_Normal*)m_pEnemyAI;
			pAI->SetVecLeapPos(start, goal);
		}
	}
}

void CEnemy::SetAIState(CEnemyAIBase::ENEMY_TYPE type, float fOrgHeight, int nJumpInterval) {    //�g���b�v�t�����[
	if (type == CEnemyAIBase::TYPE_TRAP)
	{
		if (m_pEnemyAI != NULL && m_pEnemyAI->GetAItype() == CEnemyAIBase::TYPE_TRAP)
		{
			CEnemyAI_TrapFlower* pAI = (CEnemyAI_TrapFlower*)m_pEnemyAI;
			pAI->GetOrgJumpHeight() = fOrgHeight;
			pAI->GetHighJumpInterval() = nJumpInterval;
		}
	}
}


